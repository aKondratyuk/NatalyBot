create table Category_level
(
    level_name    varchar(190) not null,
    category_name varchar(190) not null,
    primary key (level_name, category_name),
    constraint FK_CATEGORY_CATEGORY__CATEGORI
        foreign key (category_name) references Categories (category_name),
    constraint FK_CATEGORY_CATEGORY__LEVELS
        foreign key (level_name) references Levels (level_name)
);

INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('Ample', 'body_type');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('Athletic', 'body_type');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('Attractive', 'body_type');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('Average', 'body_type');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('I prefer not to say', 'body_type');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('Slim', 'body_type');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('Very Cuddly', 'body_type');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('1 child', 'children');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('2 children', 'children');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('3 children', 'children');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('4 children', 'children');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('5 children', 'children');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('6 children', 'children');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('with children', 'children');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('without children', 'children');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('I prefer not to say', 'drinker');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('No', 'drinker');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('Often', 'drinker');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('Rarely', 'drinker');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('Very often', 'drinker');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('AA (2 years college)', 'education');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('BA/BS (4 years college)', 'education');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('College student', 'education');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('Grad school student', 'education');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('High School graduate', 'education');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('Higher Education', 'education');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('I prefer not to say', 'education');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('JD', 'education');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('MA/MS/MBA', 'education');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('PhD/Post doctorate', 'education');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('Some grad school', 'education');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('4''10" - 4''11" (146-150cm)', 'height');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('4''7" (140cm) or below', 'height');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('4''8" - 4''9" (141-145cm)', 'height');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('5''0" - 5''1"  (151-155cm)', 'height');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('5''10" - 5''11" (176-180cm)', 'height');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('5''2" - 5''3"  (156-160cm)', 'height');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('5''4" - 5''5"  (161-165cm)', 'height');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('5''6" - 5''7"  (166-170cm)', 'height');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('5''8" - 5''9" (171-175cm)', 'height');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('6''0" - 6''1"  (181-185cm)', 'height');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('6''2" - 6''3"  (186-190cm)', 'height');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('6''4" (191cm) or above', 'height');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('I prefer not to say', 'height');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('$10,000-$30,000/year', 'income');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('$10,000/year and less', 'income');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('$30,000-$50,000/year', 'income');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('$50,000-$70,000/year', 'income');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('$70,000/year and more', 'income');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('I prefer not to say', 'income');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('Ample', 'looking_for_a_body_type');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('Athletic', 'looking_for_a_body_type');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('Attractive', 'looking_for_a_body_type');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('Average', 'looking_for_a_body_type');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('I prefer not to say', 'looking_for_a_body_type');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('Slim', 'looking_for_a_body_type');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('Very Cuddly', 'looking_for_a_body_type');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('4''10" - 4''11" (146-150cm)', 'looking_for_a_height');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('4''7" (140cm) or below', 'looking_for_a_height');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('4''8" - 4''9" (141-145cm)', 'looking_for_a_height');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('5''0" - 5''1"  (151-155cm)', 'looking_for_a_height');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('5''10" - 5''11" (176-180cm)', 'looking_for_a_height');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('5''2" - 5''3"  (156-160cm)', 'looking_for_a_height');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('5''4" - 5''5"  (161-165cm)', 'looking_for_a_height');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('5''6" - 5''7"  (166-170cm)', 'looking_for_a_height');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('5''8" - 5''9" (171-175cm)', 'looking_for_a_height');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('6''0" - 6''1"  (181-185cm)', 'looking_for_a_height');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('6''2" - 6''3"  (186-190cm)', 'looking_for_a_height');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('6''4" (191cm) or above', 'looking_for_a_height');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('I prefer not to say', 'looking_for_a_height');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('Attached', 'martial_status');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('Divorced', 'martial_status');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('I prefer not to say', 'martial_status');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('Single', 'martial_status');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('Widow', 'martial_status');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('Activity Partner', 'relationship');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('Casual', 'relationship');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('Friendship', 'relationship');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('Marriage', 'relationship');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('Pen Pal', 'relationship');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('Relationship', 'relationship');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('Romance', 'relationship');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('Travel Partner', 'relationship');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('I prefer not to say', 'smoker');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('No', 'smoker');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('Often', 'smoker');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('Rarely', 'smoker');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('Very often', 'smoker');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('Doesn''t matter', 'want_children');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('I will tell you later', 'want_children');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('Maybe', 'want_children');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('No', 'want_children');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('Yes', 'want_children');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('I will tell you later', 'where_children');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('living with me', 'where_children');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('not living with me', 'where_children');
INSERT INTO nataly_schema.Category_level (level_name, category_name) VALUES ('sometimes living with me', 'where_children');