create table Tagging
(
    text_id binary(16)   not null,
    tag     varchar(190) not null,
    primary key (text_id, tag),
    constraint FK_TAGGING_TAGGING2_TAGS
        foreign key (tag) references Tags (tag),
    constraint FK_TAGGING_TAGGING_Texts
        foreign key (text_id) references Texts (text_id)
)
    charset = utf8;

INSERT INTO nataly_schema.Tagging (text_id, tag) VALUES (0x698C3E5311B241CE9FA3E7BC95556320, '11');
INSERT INTO nataly_schema.Tagging (text_id, tag) VALUES (0x93D7C74D879C4E5A848C5ACD4B735EA6, '11');
INSERT INTO nataly_schema.Tagging (text_id, tag) VALUES (0xCA1C305887CF4687AFA6766068D13F1F, '213');
INSERT INTO nataly_schema.Tagging (text_id, tag) VALUES (0x3A091BFDBBB94719BAA27285983EED63, 'Can I buy your contact request at the agency?');
INSERT INTO nataly_schema.Tagging (text_id, tag) VALUES (0x94F4474DD3794C00AC7847A6765B3753, 'Can I buy your contact request at the agency? Can I get your private information, your email at the agency?');
INSERT INTO nataly_schema.Tagging (text_id, tag) VALUES (0x57834F62F0BC4D8BA1616A545DD8E5A4, 'Can I buy your contact request at the agency? Can I get your private information, your email at the agency?:)');
INSERT INTO nataly_schema.Tagging (text_id, tag) VALUES (0x3A091BFDBBB94719BAA27285983EED63, 'Can I get your private information, your email at the agency?');
INSERT INTO nataly_schema.Tagging (text_id, tag) VALUES (0x2C4D34E035B74018B8A0588734C27B83, 'Do you want to have children how many children?');
INSERT INTO nataly_schema.Tagging (text_id, tag) VALUES (0x18BB0AD2F37046F4BEAD5C56C39BF87D, 'Have You ever been abroad?');
INSERT INTO nataly_schema.Tagging (text_id, tag) VALUES (0x2E95E38F2AF34EBDAC751958A1E1B875, 'I am very sorry I have already found some one here, another lady.');
INSERT INTO nataly_schema.Tagging (text_id, tag) VALUES (0x606F06CF8EE641FB9D8A05459E3FBBF4, 'I am very sorry I have already found some one here, another lady.');
INSERT INTO nataly_schema.Tagging (text_id, tag) VALUES (0xE39829361EF042C5B3746B3DDB84B146, 'I had some bad experience of this site. I don/''t trust the ladies here. They are scammers.');
INSERT INTO nataly_schema.Tagging (text_id, tag) VALUES (0x999AF6B8F85A4784A1FFB3C07A90DE62, 'Is it possible for you to come in my country?');
INSERT INTO nataly_schema.Tagging (text_id, tag) VALUES (0x2958775B034948B984F51D260DA8F1BB, 'Is it possible for you to organize our meeting?');
INSERT INTO nataly_schema.Tagging (text_id, tag) VALUES (0x04D1BB28AD7E4123ACE6503C4BABC36A, 'Please describe what happen in future when we are together?');
INSERT INTO nataly_schema.Tagging (text_id, tag) VALUES (0x0548D75B879648339B5FF85848350B6A, 'template');
INSERT INTO nataly_schema.Tagging (text_id, tag) VALUES (0x08E7F696AEEA4280908CF22A70726835, 'template');
INSERT INTO nataly_schema.Tagging (text_id, tag) VALUES (0x285BDB97FEFD42CE8F2AB3474A4D74C6, 'template');
INSERT INTO nataly_schema.Tagging (text_id, tag) VALUES (0x42294048C3E24D4788364F5148124D51, 'template');
INSERT INTO nataly_schema.Tagging (text_id, tag) VALUES (0x73E155CCC24A41EB975CDD7654EBECA6, 'template');
INSERT INTO nataly_schema.Tagging (text_id, tag) VALUES (0x7BA508701A4E426B86A3844DEF9F1603, 'template');
INSERT INTO nataly_schema.Tagging (text_id, tag) VALUES (0x7CE85119794F41AF9DEEE0AFA32794DA, 'template');
INSERT INTO nataly_schema.Tagging (text_id, tag) VALUES (0x9924B1D7A91B4E18A0F0730C9FCDF627, 'template');
INSERT INTO nataly_schema.Tagging (text_id, tag) VALUES (0xCC05970DA9A6466C9E41AA72EAD648F9, 'template');
INSERT INTO nataly_schema.Tagging (text_id, tag) VALUES (0xD1317C0A5AF14BE8BD729D21956EDB30, 'template');
INSERT INTO nataly_schema.Tagging (text_id, tag) VALUES (0xDB6F2B91AD684E78A98DE87D27471304, 'template');
INSERT INTO nataly_schema.Tagging (text_id, tag) VALUES (0xFB3D47310D564CCAB9310630895E2B6F, 'template');
INSERT INTO nataly_schema.Tagging (text_id, tag) VALUES (0x07D3599A474544539004B78C06C7245B, 'test_delete');
INSERT INTO nataly_schema.Tagging (text_id, tag) VALUES (0x90E394E52E87450FA21E4C1FEA9277E0, 'test_delete');
INSERT INTO nataly_schema.Tagging (text_id, tag) VALUES (0xB301E1B8EAA3441EB4CF0EA35C9313FC, 'Thanks for your message but I/''m interested with other woman and im sure you will find a nice man very soon.');
INSERT INTO nataly_schema.Tagging (text_id, tag) VALUES (0xA0406DE1D4F14227B62B473AD385D498, 'What are you favorite types of music?');
INSERT INTO nataly_schema.Tagging (text_id, tag) VALUES (0x7575C3BB0798493CAE7DAE7A3C9321F7, 'What are you waiting from our correspondence? ');
INSERT INTO nataly_schema.Tagging (text_id, tag) VALUES (0x1E9C19A7651D48D39E20D6D63111779D, 'What are you wishing for in a relationship what do you expect from me');
INSERT INTO nataly_schema.Tagging (text_id, tag) VALUES (0x9CC8E29D79AA476096F7887B93C9A77B, 'What are you wishing for in a relationship what do you expect from me.');
INSERT INTO nataly_schema.Tagging (text_id, tag) VALUES (0x7F08BCCB34814627AA53253DF499682C, 'What do you like to read?');
INSERT INTO nataly_schema.Tagging (text_id, tag) VALUES (0x7B7CA21102AA4896A85D90680B4C59AB, 'What do you think about our future family?');
INSERT INTO nataly_schema.Tagging (text_id, tag) VALUES (0xC4D2ABA519A445CBAA227AE8FF86C041, 'What do you think about our future family?');
INSERT INTO nataly_schema.Tagging (text_id, tag) VALUES (0x828A7BA4794241C4A4B6B893C4AB6FA4, 'What types of food do you enjoy?');
INSERT INTO nataly_schema.Tagging (text_id, tag) VALUES (0x1C07FDDA9D984E31B3958F1E85F1DB3A, 'What would be an ideal house for you?');
INSERT INTO nataly_schema.Tagging (text_id, tag) VALUES (0x7EED4E93170445F4920EDE1A6D8A97E5, 'What you think about age difference? you are pretty very beautiful but too young. Our age difference is very big. I am way to old for you?');
INSERT INTO nataly_schema.Tagging (text_id, tag) VALUES (0x07D1837646A14494B77C7D30D5AAAD8E, 'уяввы');
INSERT INTO nataly_schema.Tagging (text_id, tag) VALUES (0xC0D243F89DEF41E09CCF550A5A848B90, 'уяввы');
INSERT INTO nataly_schema.Tagging (text_id, tag) VALUES (0x8CA01C3768844FB9A41FE7CE88E5D37A, 'фыфы');