create table Email_info
(
    email_address     varchar(190) default '' not null
        primary key,
    email_port        int                     null,
    email_host        varchar(190)            null,
    email_password    varchar(190)            null,
    email_subject     varchar(10000)          null,
    email_text        varchar(10000)          null,
    email_description varchar(190)            null
);

INSERT INTO nataly_schema.Email_info (email_address, email_port, email_host, email_password, email_subject, email_text, email_description) VALUES ('ladyjuly@a2.kh.ua', 587, 'euhost01.twinservers.net', 'iX}srvOfUH!p', 'Инструкция для регистрации в системе NatalyBot', 'Hello, admin writing to you!', 'default_register');