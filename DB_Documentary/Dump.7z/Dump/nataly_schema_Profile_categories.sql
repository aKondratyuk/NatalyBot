create table Profile_categories
(
    level_name    varchar(190) not null,
    category_name varchar(190) not null,
    profile_id    varchar(20)  not null,
    primary key (level_name, category_name, profile_id),
    constraint FK_PROFILE__PROFILE_H_CATEGORY
        foreign key (level_name, category_name) references Category_level (level_name, category_name),
    constraint FK_PROFILE__PROFILE_H_PROFILE_
        foreign key (profile_id) references Profiles (profile_id)
);

INSERT INTO nataly_schema.Profile_categories (level_name, category_name, profile_id) VALUES ('without children', 'children', '1000868043');
INSERT INTO nataly_schema.Profile_categories (level_name, category_name, profile_id) VALUES ('without children', 'children', '1001355233');
INSERT INTO nataly_schema.Profile_categories (level_name, category_name, profile_id) VALUES ('1 child', 'children', '1001485714');
INSERT INTO nataly_schema.Profile_categories (level_name, category_name, profile_id) VALUES ('without children', 'children', '1001573218');
INSERT INTO nataly_schema.Profile_categories (level_name, category_name, profile_id) VALUES ('without children', 'children', '1001600532');
INSERT INTO nataly_schema.Profile_categories (level_name, category_name, profile_id) VALUES ('without children', 'children', '1001650728');
INSERT INTO nataly_schema.Profile_categories (level_name, category_name, profile_id) VALUES ('1 child', 'children', '1001651264');
INSERT INTO nataly_schema.Profile_categories (level_name, category_name, profile_id) VALUES ('without children', 'children', '1001663985');
INSERT INTO nataly_schema.Profile_categories (level_name, category_name, profile_id) VALUES ('2 children', 'children', '1001668497');