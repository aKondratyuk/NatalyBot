create table Message_anchors
(
    profile_id varchar(20) default '' not null,
    text_id    binary(16)  default                  not null,
    primary key (profile_id, text_id),
    constraint Message_anchors_Profiles_profile_id_fk
        foreign key (profile_id) references Profiles (profile_id),
    constraint Message_anchors_Texts_text_id_fk
        foreign key (text_id) references Texts (text_id)
)
    charset = utf8;

INSERT INTO nataly_schema.Message_anchors (profile_id, text_id) VALUES ('1001636771', 0x04D1BB28AD7E4123ACE6503C4BABC36A);
INSERT INTO nataly_schema.Message_anchors (profile_id, text_id) VALUES ('1001651264', 0x07D1837646A14494B77C7D30D5AAAD8E);
INSERT INTO nataly_schema.Message_anchors (profile_id, text_id) VALUES ('1001636771', 0x18BB0AD2F37046F4BEAD5C56C39BF87D);
INSERT INTO nataly_schema.Message_anchors (profile_id, text_id) VALUES ('1001636771', 0x1C07FDDA9D984E31B3958F1E85F1DB3A);
INSERT INTO nataly_schema.Message_anchors (profile_id, text_id) VALUES ('1000868043', 0x1E9C19A7651D48D39E20D6D63111779D);
INSERT INTO nataly_schema.Message_anchors (profile_id, text_id) VALUES ('1001636771', 0x2958775B034948B984F51D260DA8F1BB);
INSERT INTO nataly_schema.Message_anchors (profile_id, text_id) VALUES ('1001636771', 0x2C4D34E035B74018B8A0588734C27B83);
INSERT INTO nataly_schema.Message_anchors (profile_id, text_id) VALUES ('1001636771', 0x2E95E38F2AF34EBDAC751958A1E1B875);
INSERT INTO nataly_schema.Message_anchors (profile_id, text_id) VALUES ('1000868043', 0x3A091BFDBBB94719BAA27285983EED63);
INSERT INTO nataly_schema.Message_anchors (profile_id, text_id) VALUES ('1001636771', 0x57834F62F0BC4D8BA1616A545DD8E5A4);
INSERT INTO nataly_schema.Message_anchors (profile_id, text_id) VALUES ('1001636771', 0x606F06CF8EE641FB9D8A05459E3FBBF4);
INSERT INTO nataly_schema.Message_anchors (profile_id, text_id) VALUES ('1001651264', 0x698C3E5311B241CE9FA3E7BC95556320);
INSERT INTO nataly_schema.Message_anchors (profile_id, text_id) VALUES ('1001636771', 0x7575C3BB0798493CAE7DAE7A3C9321F7);
INSERT INTO nataly_schema.Message_anchors (profile_id, text_id) VALUES ('1001636771', 0x7B7CA21102AA4896A85D90680B4C59AB);
INSERT INTO nataly_schema.Message_anchors (profile_id, text_id) VALUES ('1001636771', 0x7EED4E93170445F4920EDE1A6D8A97E5);
INSERT INTO nataly_schema.Message_anchors (profile_id, text_id) VALUES ('1001636771', 0x7F08BCCB34814627AA53253DF499682C);
INSERT INTO nataly_schema.Message_anchors (profile_id, text_id) VALUES ('1001636771', 0x828A7BA4794241C4A4B6B893C4AB6FA4);
INSERT INTO nataly_schema.Message_anchors (profile_id, text_id) VALUES ('1001651264', 0x8CA01C3768844FB9A41FE7CE88E5D37A);
INSERT INTO nataly_schema.Message_anchors (profile_id, text_id) VALUES ('1001651264', 0x93D7C74D879C4E5A848C5ACD4B735EA6);
INSERT INTO nataly_schema.Message_anchors (profile_id, text_id) VALUES ('1001636771', 0x94F4474DD3794C00AC7847A6765B3753);
INSERT INTO nataly_schema.Message_anchors (profile_id, text_id) VALUES ('1001636771', 0x999AF6B8F85A4784A1FFB3C07A90DE62);
INSERT INTO nataly_schema.Message_anchors (profile_id, text_id) VALUES ('1001636771', 0x9CC8E29D79AA476096F7887B93C9A77B);
INSERT INTO nataly_schema.Message_anchors (profile_id, text_id) VALUES ('1001636771', 0xA0406DE1D4F14227B62B473AD385D498);
INSERT INTO nataly_schema.Message_anchors (profile_id, text_id) VALUES ('1001636771', 0xB301E1B8EAA3441EB4CF0EA35C9313FC);
INSERT INTO nataly_schema.Message_anchors (profile_id, text_id) VALUES ('1001651264', 0xC0D243F89DEF41E09CCF550A5A848B90);
INSERT INTO nataly_schema.Message_anchors (profile_id, text_id) VALUES ('1000868043', 0xC4D2ABA519A445CBAA227AE8FF86C041);
INSERT INTO nataly_schema.Message_anchors (profile_id, text_id) VALUES ('1001651264', 0xCA1C305887CF4687AFA6766068D13F1F);
INSERT INTO nataly_schema.Message_anchors (profile_id, text_id) VALUES ('1001636771', 0xE39829361EF042C5B3746B3DDB84B146);