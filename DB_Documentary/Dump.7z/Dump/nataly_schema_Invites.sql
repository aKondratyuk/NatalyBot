create table Invites
(
    invite_id   binary(16)                          not null
        primary key,
    create_time timestamp default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP
);

INSERT INTO nataly_schema.Invites (invite_id, create_time) VALUES (0x15AFE4472CEC4D9EAA9FA9CBF9AA3BE0, '2020-10-11 13:14:05');
INSERT INTO nataly_schema.Invites (invite_id, create_time) VALUES (0x1B58F36CD07845DFB485F9092F26D3FD, '2020-10-19 12:22:21');
INSERT INTO nataly_schema.Invites (invite_id, create_time) VALUES (0x3936F24B40DF46408F31AE0F8B4EE92F, '2020-10-13 11:10:25');
INSERT INTO nataly_schema.Invites (invite_id, create_time) VALUES (0x3F019B59F3AD47CEB82A26FA8BAE4C32, '2020-10-11 13:23:09');
INSERT INTO nataly_schema.Invites (invite_id, create_time) VALUES (0x7A30AF30691645B8AA065DDA581A674D, '2020-10-05 18:02:39');
INSERT INTO nataly_schema.Invites (invite_id, create_time) VALUES (0x83D7B0ECE4F743978C79147C43D3AD7C, '2020-10-07 22:54:24');
INSERT INTO nataly_schema.Invites (invite_id, create_time) VALUES (0x9A3E9A31DED94D13A2EE0C19B23E57E3, '2020-10-07 22:54:20');
INSERT INTO nataly_schema.Invites (invite_id, create_time) VALUES (0xBE569A49D02348F8AB1FC1F503B2B157, '2020-10-07 13:15:50');
INSERT INTO nataly_schema.Invites (invite_id, create_time) VALUES (0xE3AFCB520090474090DABE690ECEE909, '2020-10-11 18:07:05');
INSERT INTO nataly_schema.Invites (invite_id, create_time) VALUES (0xE6D78DF97E2F4C278B3730277282E463, '2020-10-07 13:15:40');