create table Used_anchors
(
    profile_id varchar(20) default '' not null,
    text_id    binary(16)  default                  not null,
    primary key (profile_id, text_id),
    constraint Used_anchors_Message_anchors_text_id_fk
        foreign key (text_id) references Message_anchors (text_id),
    constraint Used_anchors_Profiles_profile_id_fk
        foreign key (profile_id) references Profiles (profile_id)
)
    charset = utf8;

