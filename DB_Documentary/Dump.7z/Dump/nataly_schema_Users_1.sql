create table Users
(
    login         varchar(190) not null
        primary key,
    user_password varchar(190) null
)
    charset = utf8;

INSERT INTO nataly_schema.Users (login, user_password) VALUES ('111@gmail.com', 'deleted');
INSERT INTO nataly_schema.Users (login, user_password) VALUES ('124@gmail.com', 'deleted');
INSERT INTO nataly_schema.Users (login, user_password) VALUES ('145@gmail.com', 'sha256$oTBi6IeW$4b54cf2749f79d3b41ae8f21e976eaaa16f0a4b69bd86f9a069487e202a68288');
INSERT INTO nataly_schema.Users (login, user_password) VALUES ('335@gmail.com', 'deleted');
INSERT INTO nataly_schema.Users (login, user_password) VALUES ('375@gmail.com', 'sha256$cSQ9mSMy$3cdffd306c177ca0e073286e8c4308c0f2b52e69d1e94619214399de3a3f4050');
INSERT INTO nataly_schema.Users (login, user_password) VALUES ('786@gmail.com', 'deleted');
INSERT INTO nataly_schema.Users (login, user_password) VALUES ('793@gmail.com', 'sha256$aCWoByHV$7bcff75292c8f1b91b2eda52d1be3e4a29faf7d85f636fc17fb2d96a9d471e0c');
INSERT INTO nataly_schema.Users (login, user_password) VALUES ('795@gmail.com', 'sha256$V7cQjdki$992aeaa02bdd7c68924eb0f6f0145981cd4590dc15f266549528d513d1596937');
INSERT INTO nataly_schema.Users (login, user_password) VALUES ('842@gmail.com', 'deleted');
INSERT INTO nataly_schema.Users (login, user_password) VALUES ('admin2@gmail.com', 'deleted');
INSERT INTO nataly_schema.Users (login, user_password) VALUES ('admin3@gmail.com', 'sha256$g5s9XzFP$c4c197fa413f9873b3241493f635890827f841b8e8093e418028642ebd5fac20');
INSERT INTO nataly_schema.Users (login, user_password) VALUES ('admin@gmail.com', 'sha256$RgDpo8YJ$c4a830dfa1b1665a8411787d1e54b30102d7e4d3ccca9f3729e44e50d479d525');
INSERT INTO nataly_schema.Users (login, user_password) VALUES ('andrey-klarkent@ukr.net', 'sha256$I9U5y9iy$2fef245d65a4c1cb3b179421a864c0c069d63fe4413022bac72cb07e05d021cc');
INSERT INTO nataly_schema.Users (login, user_password) VALUES ('android2898@gmail.com', 'sha256$9HWgs0gL$7d475f71843729314dc73300d0adead3f528434c127268cf31e42b53c24b5849');
INSERT INTO nataly_schema.Users (login, user_password) VALUES ('anonymous', 'anonymous');
INSERT INTO nataly_schema.Users (login, user_password) VALUES ('illya123456@live.ru', 'sha256$6X8zwxol$4a3941b42f340ce2cdf71a1059e2310b918fd45fcd1b5c5d76e9c953f47b8d6f');
INSERT INTO nataly_schema.Users (login, user_password) VALUES ('illya123456@outlook.com', 'sha256$l06pkrFb$727afb6f1a556d887b79856130fa09ca85dc970c6fbed87776c94657845a6bf2');
INSERT INTO nataly_schema.Users (login, user_password) VALUES ('julia777happy@ukr.net', 'sha256$tHCHZPZA$8d2c5f30ee3d78b64b6bba5f1e937b1dac8997188611dab5ab025924cd8224e7');
INSERT INTO nataly_schema.Users (login, user_password) VALUES ('l124@gmail.com', 'deleted');
INSERT INTO nataly_schema.Users (login, user_password) VALUES ('plug2up@gmail.com', 'sha256$RLdo1P0N$6947d7257b5c62c3f4813c697838d8618692392c1fab4b26863fca83ed7d056c');
INSERT INTO nataly_schema.Users (login, user_password) VALUES ('r.buhtiyarov@gmail.com', 'sha256$C02QpsFY$cfe28fa5e13a9518f555e275df02ea746fb8d59aab81b55e1f7d4a5b44eea63b');
INSERT INTO nataly_schema.Users (login, user_password) VALUES ('server', 'server');
INSERT INTO nataly_schema.Users (login, user_password) VALUES ('test_invite@gmail.com', 'sha256$uYZJZnM7$3a6237dae55345533ef319bb6ed9ae9f81cb9029bd700aa720082005b2379265');
INSERT INTO nataly_schema.Users (login, user_password) VALUES ('yulia777lovestory@gmail.com', 'sha256$cDmeVjbP$cf020c6a3df25d775d4bf2254f98930da93e4eb8aa359a1b6ae61b3b1f56f4d1');