create table Visibility
(
    profile_id varchar(20)  not null,
    login      varchar(190) not null,
    primary key (profile_id, login),
    constraint FK_VISIBILI_VISIBILIT_PROFILES
        foreign key (profile_id) references Profiles (profile_id),
    constraint FK_VISIBILI_VISIBILIT_USERS
        foreign key (login) references Users (login)
)
    charset = utf8;

INSERT INTO nataly_schema.Visibility (profile_id, login) VALUES ('1001663985', 'illya123456@live.ru');
INSERT INTO nataly_schema.Visibility (profile_id, login) VALUES ('1001636771', 'r.buhtiyarov@gmail.com');