create table Texts
(
    text_id binary(16)     not null
        primary key,
    text    varchar(10000) not null
);

INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x003E580238444C0188218C3B30431FEE, '
Julia, 
I really loved your answers to my questions.  Very glad to hear about the second job as well.  I''m proud of you.  Coffee and chocolate are my favorite things too!
I want to tell you that the day that we meet will be the happiest day for me. You are everything and more that I dream of.  Even through a letter I can say for sure. 
Today is my day off and I''m thinking of you.  
Yours always 
Dave');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x009B861565374155AB448B07B006DA26, '
Dear Julia. I wrote to you already an hour after you sent me a letter yesterday. I can look at the site you have opened and read my mail and replies? As I have written before, I am waiting for credits so I can read more than the first line of your letters. I hope the site opens soon so I can read it all. I long to communicate properly with you. I also hope you have the patience to wait. Love from John');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x045A692136114FC18B706A59565959D1, '
My dear Miss Sun, Julia, first of all, please guess what song this is?
I wish this night to last forever
we could always be together
But by the dawn you ll be gone
once more I will be left all alone
Before you go my precious one
My only love, my brightest sun
I have one wish before you fly
Please come back tomorrow night
No one is more than you
Nothing compares to you
I am glad that the warm weather surrounds you. I know that good weather can improve people''s mood. Autumn is the harvest season, maybe we can also harvest some.
Yes, nothing in the world can stop two hearts wanting to be close to each other. Our hearts are a safe haven for each other. There is a poem in China that says: As long as the two loves stay the same until death, why bother to be greedy for my love and joy. I think this mood suits us well, because we may not be able to meet each other in a short time. Of course, maybe the Internet can help us.
do you know? I am used to a person falling asleep. Last summer, my daughter was scared at night and asked me to accompany her. But I can''t sleep all night, and I''m not used to the feeling of someone around me. Do you have such experience? Maybe loneliness should belong to me?
I am honored to be your gardener, watering you, taking you to the sun, sheltering you from wind and rain, and watching you become more beautiful. I think this will be a perfect experience.
It seems that Ukraine’s income is indeed lower than that of China. Do you know how much the ticket to Kiev is now? This requires connecting flights to two countries, about 85,000 hrn one-way, but before the epidemic, a round-trip ticket to Kiev only needed more than 30,000 hrn. I think maybe I need to find a way to make more money.I plan to move to my company to live, so that I can save some rent. At the same time, I took the trader exam. If it goes well, I can make money by investing in the futures market. Will you cheer me on?
I recently read some travel notes about Ukraine written by Chinese people, which gave me a better understanding of Ukraine. It seems that Ukrainians are not very friendly to Chinese. The airport staff will try to charge an extra fee to the person applying for the visa, which is about $60 per person. Taxis at the airport will also make guests pay more. But in the city, I think it is still very good, people are very enthusiastic and willing to help tourists. Is it really? Do you know these?
Yes, if you want to get the best treatment in China, you need to use imported medicines. This is very expensive, so the national medical insurance cannot be reimbursed. I can only choose to purchase another medical insurance from the insurance company. Last month, my mother fell and hurt her knee. It took about 10,000hrn to check up, and then the doctor said to go home and rest. It has been 50 days and she is much better now, so don''t worry.
Yes, I stayed at home with my little witch for more than two months. I felt very good at first, and I could spend time with her. But after more than a week, I became irritable. I had to help her do homework, play with her, cook her food, and coax her to sleep. It''s like this every day, it''s too hard. Fortunately, this time has passed.
I have applied to the website for your personal contact information, and I look forward to communicating with you freely so that we can share more details in life. I''m very excited. As for the language, it doesn''t matter. I can use Russian. Although there will be some minor flaws after translation, I don''t think it will affect the two hearts that yearn for each other, right?
I think viruses will be the theme of the whole world in the next few months, and I hope you all are well.
My Wednesday was rainy, but it has passed. My Thursday is sunny, but the temperature is already very low. I need to wear a jacket.
I hope my letter will bring you warmth, my Miss Sun.
靖');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x066A88924EE94517B41500EEE3D5675F, '
Julia,
I miss you a lot.  Sometimes it almost feels to me that we know each other in person.  I hope you are doing good.  I think about you every day.  Do you think of me too?  Talk to you soon.
Yours always 
Dave');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x07B2368964B34008B1655B3DDE4E6378, '
Hello Julia, I would like very much to meet you and for you to know me, ');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x0803EC6908A4462AAA5FAEAAA89597D9, '
My dear Julia, I guess you are still asleep now. But I want to say good morning, I hope you don’t think it’s too early. 
I went for a run in the morning and felt my heart was about to jump out of my mouth. It seemed that I hadn''t exercised for a long time. I think I need to exercise more, otherwise we will become beauty and the beast together.
I miss you, so I want to write to you, I hope you can see my greetings in the morning. It is still six letters before we can communicate freely. I look forward to it. This way I can share moon cakes and moon pictures with you.
Is cash still being used more in Ukraine? Mobile payment in China is very convenient now, you may not know, I have not used cash for a year, and there are only a few lonely credit cards in my poor wallet. You can even pay with your mobile phone by bus and taxi.
On September 14, a city in southern China was closed because stowaways entered there and brought the virus. I can''t understand, isn''t it a problem for the world to control the virus? Why spread it everywhere? This incident caused everyone in that city to do nucleic acid testing, which was terrible. Fortunately, China''s vaccine is about to go on the market. I think maybe the virus will be eliminated.
Yesterday, it started to snow in a city 300 kilometers away from my home. I think winter may come earlier this year. Maybe I should find out the winter clothes in advance.
Well, just write here, you have to cheer today.
Hugs
Jing');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x08496E1178E242818527FF8E1BD4E36E, '
My dear Julia, I don''t want you to be my candle, because I can''t bear to light it, because after a short period of light, I will lose you. Maybe you can think of a better analogy, haha. For example, you can be my book, so that I can always hold you in my palm, and all my eyes can see are you.
It''s nine o''clock in the evening. I went for a walk in the evening and ran for a while. I received your letter as soon as I got home. perfect.
You already know my name, but it is in English, maybe you can''t understand it well. I wrote it in Chinese characters for you:靖.Does it seem difficult to write? You can try.
I like your story. I think life is so plain many times. We need to enjoy every detail and find the joy of life from the ordinary, because I have wasted too much time and endured a boring life. I think maybe you can become my savior.
The music I listen to when I am walking is all about love, which makes me think of you. It feels terrible to see other couples walking by my side hand in hand. So I try to go to places with few people. Do you feel this way?
Okay, I''m going to sleep, I hope we can meet in a dream. Tomorrow morning I will continue to get up early to exercise. Losing weight is really a matter of perseverance.
good night
Jing  ');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x08755689CC8B40AAA47E0FB4674DC797, '
Hey Julia my dear,
Thanks so much for your wonderful letters to me.  It really means a lot especially when it''s cold.  Your letters warm my heart.
Today and tomarrow are my days off.  So I''m in a pretty good mood.  When I got home from work I  napped for a little while.  I''m going to go help the grandparents with leaves in their yard. Then later today perhaps I''ll order some fancy takeout. ( I wouldnt sit in a restaurant alone) hehehe. Then tomarrow I have to get some more work done on my car.  Then I''ll see friends.  
Hope you have enjoyed your free time.  You deserve it.  I''ll be thinking about you.
Yours always
Dave');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x097A38BEE07447EBA3CD37B53D2A8163, '
Julia eres tan bella y tan sutil que cualquiera caeria rendido a tus pies, nunca cambies tu porte elegante y sobrio luces fantastica, me encantaria conocerte bien');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x0A928A5358294CBF87320F14EC5E0000, '
My dear Julia, I don''t want you to be my candle, because I can''t bear to light it, because after a short period of light, I will lose you. Maybe you can think of a better analogy, haha. For example, you can be my book, so that I can always hold you in my palm, and all my eyes can see are you.
It''s nine o''clock in the evening. I went for a walk in the evening and ran for a while. I received your letter as soon as I got home. perfect.
You already know my name, but it is in English, maybe you can''t understand it well. I wrote it in Chinese characters for you:靖.Does it seem difficult to write? You can try.
I like your story. I think life is so plain many times. We need to enjoy every detail and find the joy of life from the ordinary, because I have wasted too much time and endured a boring life. I think maybe you can become my savior.
The music I listen to when I am walking is all about love, which makes me think of you. It feels terrible to see other couples walking by my side hand in hand. So I try to go to places with few people. Do you feel this way?
Okay, I''m going to sleep, I hope we can meet in a dream. Tomorrow morning I will continue to get up early to exercise. Losing weight is really a matter of perseverance.
good night
Jing  ');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x0D302E87DB6D47D5BE7AD05E157F3F0A, '
Hola, gracias por interesarte en mí y saber algunas cosas más, soy de PERU, región Junín, Provincia de Huancayo, soy profesor, me gusta las cosas serias y correctas, llevo en mi alma y ser, los valores de antaño, no soy perfecto , pero sí muy sentimental y sincero, no busco juegos  o placer sino una compañera, alguien amar por siempre y para siempre, cuidarla, respetarla, engreírla , protegerla todo lo que ella realmente debería de tener, y para mí, solo le pediría que me ame solo a mí con todo su corazón y que sea mi musa (mi inspiración o motivo) y si hubiera algún problema o alguien en su vida, o algo va mal que me diga, aunque las verdades son dolorosas, que sea SINCERA y de mi parte ¡Confía en mí y lo veras!, no te decepcionaré, me gustaría algún día viajar o conocer tu país, pero por diversas razones no puedo por ahora, quizás algún día y solo iría por ti a verte; veo que por ahora la distancia es obstáculo para nosotros, pero si dos personas se aman , la distancia se hace corta, ¡No sé si esto es la manera por correspondencia, pero es un paso!, estoy intentando salir adelante con ayuda de DIOS, poco a poco, las cosas para mí son difíciles pero no me rindo o me doy por vencido, algún día tendré mejores oportunidades para darle una vida de ensueño a mi futura esposa e hijos y que no le falte nada, es por eso que es una de las razones que no podre escribirte seguido, porque trabajo lejos, en una provincia de Chanchamayo (selva) y es lejos y no hay internet, ten paciencia conmigo, no sé si te importa la riqueza o las cosas lujosas, pues lo entenderé; yo valoro muchísimo los sentimientos, los valores y la actitud de las personas y confiar aunque te paguen mal, las cosas materiales se desvanecen, pero si tener lo necesario y algunas comodidades, mi corazón esta solitario y tiempo solo, pensando en encontrar algún día aquella Dama que se enamoraría solo de mí y yo de ella, solo de ella, casarme con ella y servirla y q me ayude, compartir muchas cosas y hacer locuras por toda nuestra existencia, aprender del uno y lo otro, etc; sé que eres hermosa, veo en tus ojos: dulzura, delicadeza, sensualidad, feminidad, pero hay algo más dentro de ti, y me gustaría muchísimo conocerte más, cariño. BUENO CUIDATE MUCHO, BEZOS Y ABRAZOS A LA DISTANCIA CON MUCHO CARIÑO,DE FERNANDO CORDOVA RAMOS…..');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x10260B06E4154402A84465E978007DC3, ' I welcome you warmly. At the beginning I wanted to... ');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x144E97A8AC6346A18B3D5265987F604D, ' dear Julia   thanks for your letter. the big diffe... ');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x17F562E5D1884837A8E1103A915395BA, ' Hi Julia, thank you for your letter and thoughts o... ');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x19317D1F25FD48D6BF7C11DB121C7085, '
Jing, Since early morning  it is a strange desire for passionate hugs and kisses…  May  be  it  is  the  scent  of  autumn  lack  of  Love  You notice that autumn is the most depressive period during the year Every autumn I have a strong desire to fall in love and enjoy this process together with my beloved. 
Do you feel any monotony at your life? I notice  that I do the same things every day such as automatic system. It is the strange feeling... I need the bright flash of love in my life immediately because the depression is too close to me. Did you feel the same ever?  I want  to try something new in my life.May be I must replace the furniture at my home. How often you can change anything cardinally at your home atmosphere, for example, Jing?
The situation with COVID-19 is more difficult day by day. We have the highest statistics during all period of the virus in Ukraine. I am afraid of new strict quarantine in our country. How is the situation in your city now?
I will answer for all your questions during next lunch time Sorry
Julia');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x1B7D4785147D434982F9D4F10A38195A, '
My dear lady Julia, our latitudes are similar, so the weather is similar, the only difference is that my hometown is windy. But this kind of weather is very good, because I am afraid of heat, summer is very difficult for me. I prefer winter.
It seems that you are very good at dancing and hope to have the opportunity to appreciate it in the future. Of course, you can also become my personal dance teacher.
After a day of work and returning home, my favorite thing is to lie on the sofa and relax. I don’t drink when I am alone because I am not good at drinking. Drinking is a very effective way of socializing in China. People decide something by eating and drinking, and it is easier to reach consensus than negotiating table.
Being alone for too long, I can''t think of how to help you relax after get off work, but I want a hug, a kiss, and a delicious dinner. I can do well. Maybe I lack romantic genes, but I think you will help me. I think you are a very romantic person.
I am very happy that you can handle the busy work skillfully. This is one of our survival skills. I think the first element of a good job is to love it. I also love my work and I can handle them well. Of course, I am not as busy as your work. I read your information that you work in a construction company. I think girls rarely work in the construction industry, at least in China. I have also worked in a real estate company, so fortunately, we used to be colleagues.
My time here is faster than yours. It''s 5 pm now. I also got off work. I can go home. Of course I rented a house in the city, my home is not in the city, a small town 80 kilometers away. I looked up your city on the Internet, but there is very little information. Can you tell me something?
I found that Ukrainians can speak two languages, Ukrainian and Russian. Chinese schools will require us to learn English, so I can learn some English. I think Russian is more difficult than English because I have taught myself a little bit. If we meet in the future, should I use a translator?
Wish you a happy day
Ralf');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x233AFCE9137A401AAC5BA53A88BD66A2, '
Hola Julia, gracias por tu carta sincera y aprecio tus palabras y preguntas, te cuento de mi, estoy separado y estoy viviendo en mi casa con una hija que está estudiando en la universidad,en mi madurez he querido explorar buscando mi pareja en Ucrania aunque bastante lejos de Colombia aquí no he podido hallar la pareja ideal pienso que me entregué al trabajo que amo con pasión, soy arquitecto  y descuide la parte sentimental, sin embargo no dejo de ver esta página guardando la esperanza de encontrar una mujer ucraniana que quiera conocer un hombre serio y maduro para formar un hogar reconozco que soy algo mayor y me gustaría conocer una mujer joven como tu y algo más me gustaría vivir un corto tiempo en tu país si llegaremos a congeniar seria increíble para eso primero hay que conocernos pronto puede ser por Telegram o WhatsApp si te parece bien, bueno Julia espero mi mensaje te alegre el día y nos permita realizar nuestros deseos y planes futuros, recibe un saludo con mucho cariño, Fernando ');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x239A35DC36C841F78F002CF7E1FF78D7, '
My dear Julia, I know what you mean. Autumn should be the harvest season, but we will feel lost if we have empty hands. But I think this autumn is a special season. Because we know each other. Hope this can change your mood.
My life is as monotonous as yours. This is the test of life for us. We must learn to find our own pleasure from some details. Now, you are the sunshine that illuminates my gray life, so I will bless you from afar until we meet. I don''t care much about the layout of the home. This may be the difference between men and women. I think most men don''t care about such details. But if my lover wants to change, I will actively participate in the design of new plans.
Yes, the virus is becoming serious, and we have no better way. We can only look forward to the launch of the vaccine. I heard that Chinese vaccines will be available as early as November. China is very good. There is almost no virus in the country. Almost 2,000 patients who have been diagnosed have entered China from abroad. China has strict border inspections, which has protected us very well. I think maybe China is one of the countries with the least virus in the world. I feel very lucky, because when the virus first broke out in China, everyone was very scared, but we controlled the spread of the virus very well. And everyone obeyed the government''s arrangements without any complaints. This is unimaginable in many other countries. What do you think?
It''s 10 o''clock in the evening, I am ready to go to bed, looking forward to you walking into my dream.
Also wish you a good dream in advance
靖  ');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x2592627DA85B421BB073FEBAA5274EF1, '
My dear Julia, like us, it is rainy here today, of course I am also sleepy.
I hope you have received my mail and I am waiting for your reply.
I think Ukraine has less food than China, because the Chinese eat chicken feet, pig feet, and animal offal. As for me, I like to eat trotters and lamb belly. Maybe I have a chance in the future and I can take you to taste it. I think you will love them too. Do you have any special ingredients?
Because the holiday is approaching, my work is very leisurely, so we will enter the holiday early. I can go home tomorrow afternoon and enjoy my 10-day holiday. I don''t have any plans yet, do you have any suggestions?
I know you are afraid of the cold, so I give you a warm hug on a rainy day
靖  ');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x260A8664DFB34AECA79270C65C06CA9D, '
Hi Jing,  It is sooo soo soo wonderful Tuesday  This morning I got up later than usual and I was very hurry up and even without breakfast.  I try to be organize and attentive but sometimes I can’t wake up earlier. It is too difficult to wake up very early during the dark autumn mornings  What about You, Jing?  
Yes I lived abroad during the 14 days.  I liked this style of the life. Yes I realise sometimes my life in China But I need a good excursion there in your place
Arbitrage, is a name of our future book It is a little joke" not a serious real book
Yes we can practise our languages together with You It will be a very pleasant and useful experience But we need wait a little bit
One little secret for you My colleague is pregnant (she said me about this in the morning). But she feels tired and sleepy, she feels sickness all time and I can’t help you her anything. I guess that it is enough difficult to be pregnant Do you have the close peoples who are pregnant right now? 
And about my evening let’s have supper together?  I am going to cook  Mlyntsi:  are these crepes filled with a variety of stuffings,  including sweetened cottage cheese and jam,  then coated in fresh butter and baked, and then served hot with Smetana.  One day I would cook this dish for you,  Jing.
You must know that  in spite  of my age,  I have attained a level of maturity that well-prepares me to begin my own family. On the other hand, I amstill a young flower that needs tender love and care, with plenty of room to grow as I blossom forth from within. Will you be my gardener, Jing ?
The covid is cover Ukraine more and more… I need your tender hugs during this depressive period… 
Julia');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x26DA608D554E4184B69CB93508B46EE8, '
My dear ladyJulia, I am very happy to receive two letters from you, which can help me to alleviate the missing you.
My hometown is colder in autumn. I prefer to stay in a warm bed. It is perfect if there is a lover by my side, but you are not there. So you write to me more, promise me?
Regarding the energy exchange you said, I don’t know much, but there is another way of saying it in China. A man represents yang, and a daughter represents yin. The fusion of yin and yang is perfect. So a man can''t stay alone, he must find a good woman like you to accompany him through the road of life, support and help each other. What do you think?
do you know? My hometown is the same latitude as Bordeaux in France, so what are the specialties of my hometown? Grapes and wine, the earliest wine in China was produced in your hometown, do you yearn for my hometown more? It''s just the season when the grapes are ripe. There are many grape picking gardens open now. Many different kinds of grapes can be picked. I want to go with you.
I look forward to your breakfast, although I have no chance to taste it now. But we have one thing in common. We all go to work by bus. Of course, sometimes I choose to walk to work. It takes about half an hour. Walking is also a method of exercise. I think it must be nice for us to walk together.
I can''t imagine the charm of your dress, which might make me intoxicated like old wine. I am willing to be attracted by your charm, which makes me want to know you more.
Speaking of work, what I used to do was to communicate with machines, but I didn''t like it, so now I communicate more with people, finding ways to complete difficult tasks is a very fulfilling thing, isn''t it?
t is a pity that I have never ridden a horse. There are very few opportunities to ride a horse in China. Maybe you can teach me some knowledge. You may be able to teach me in the future, my dear teacher Julia.
Finally, ask a question. Guess which photo I like best in your album? Take a look at me and your appreciation of your charm is consistent? Looking forward to your answers.
looking forward to your reply
With love
Jing  ');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x28E5E79D4B6A4971A49124D471FB5127, '
NICK_771234, LOOK INTO MY EYES AND MAYBE YOU WILL SEE THERE YOUR HAPPINESS? Your lady Julia is waiting for the first step from you;)) How are you doing here, NICK_771234?	
Dear are you ready for your life''s great journey called love? I am… and I hope it starts here and now! Smile
I will be glad we will use this chance to know each other better! Hope my first letter will catch your attention! 
I looking to meet a person with whom I can build a long-term relationship,and who will be reliable, caring, and loving as we walk through the rest of our lives side by side. Of course I am not talking about  Ukrainian man, as they are all liars, dishonest and looking only for a one night relationship, they are not loyal because we have so many nice and beautiful, talented and intelligent ladies... But I don''t want to be  a doll for a silly games,  I do value loyalty and don''t want to have broken heart! I know, what I want from life - I appreciate family values. Why you are looking for the woman abroad, NICK_771234? How about local ladies?
For me - the creation of family is a not temporary phenomenon, it is - something steady. I''m searching for friend, husband, partner, companion of life to make you and me happy and to be for you true and happy woman! That is why it''s very important for me to find the husband of my heart, because life is empty without Love and beautiful feelings! I am looking for such man with the qualities you have caring and loving, reliable and understanding. Do you have such qualities to make your wife happy, NICK_771234?
It is  so interesting to learn another culture and language (I am in process of learning English) and enjoy the foreign customs. Don’t ruin my hope to recolate in your country and be happy with you, because my place is near my man! I wish you have a great eager to know me better, to reveal my personality and hope life have prepared only pleasant surprises for us) I want to be your best surprise in life....Let''s use our chance!!!!
I don`t want so much... just to be happy. 
I want to be happy I mean really happy again, and see my man happy too.
I really wish you a nice day, NICK_771234
Hope for your answer soon,
Julia
');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x2DC09CFB004E4426A94A388EAAF563F2, '
Dear Julia,
I trust that you are fine and well today. Your interesting message was very positive and thought provoking and made me feel aroused. Happy to meet you here and hope we can start a serious relationship which will bring us together to fall in love. You and I have different life experiences yet we both want to fill our lives with love so let our chemistry ignite an explosion of passion to make us an idea match. My eyes tell me you are a special woman who is very beautiful with strong inner beauty and loving passion in your heart and soul. I want a real meeting in Rivne, so we discover how wonderful life is when our desire to be loving partners in all aspects of life becomes a reality. I feel that as we get to know each other we will be drawn together as the honeybee is attracted to pollinate the beautiful flower when it opens under the bright sun. We can have complete emotional and physical intimacy, so the heat of our romance leads us to explore new horizons together that will take to us a future where two halves join as one in a place where no borders exist. Julia, my desire here is to begin a serious loving relationship that leads to having a wife who is very beautiful, natural, romantic, passionate, charming, tender, adventurous, active, sensitive, sensual, very hot and sexy. I feel that you have all these qualities and more which make you my idea woman. When we are together you to will find me a serious, loving, romantic, faithful, generous, hardworking, cheerful, tender sexual man. If you choose to be my mate to build a family life it will be my focus to make you happy, so the sexual and romantic side of our deep love will bring us smiles, tender kisses, sensual fragrances, arousing touches as I give you deep, blissful, burning, orgasms of electric pleasure when we make love. Emotionally I want to create in her strong feelings that she is special and supported in a way that she is confident in all aspects of life, so our love continues to grow stronger. Have you considered the idea of creating in England a loving union that will bring pleasure and happiness when we taste sweet love together? Julia, I hope that you write more about yourself and how you want your life to be in the future? It seems that we are both seeking a traditional family. I am willing to take full responsibility for the provision of all the material and emotional comforts for my wife. I will tell you more about myself and my life as we become emotionally closer. Julia, on our first date there where to you want me to take you. I will answer your questions however personnel as we open our minds and express our feelings to each other before we come face to face to share the bright colours of life as we hug, French kiss, taste each other, bathe, travel and couple as one in the naked flame of love. Julia, I think of you with sweet hot desire. I give you my sweet tender kisses and strong protective hugs.
Yours Rick
XXXXXXXXXXXXXXXXX
');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x2EBF386FEA1142A3B4FE7C1063D6BDCC, '
My dear Julia, I have applied for your personal contact information, but I haven''t received a reply yet.
I think you already know how to write my name in Chinese characters. Are you not curious about your name? Let me tell you, Julia=茱莉亚. Very beautiful words, right? Hope you like them.
Actually I am a lazy person, I don''t want to be rich, I just want to have a quiet life. But if I want to see you, I have to make changes. This is my motivation. My assessment has completed 6% this week. If it goes well, I will be eligible for futures investment and an account in five weeks. I have worked in the financial industry for 6-7 years, so I can be your personal financial advisor.
Very good, I think my personal guard can help me experience life in Ukraine better. I look forward to it.
I recently watched the news. Russia wants more Chinese men to marry Russian girls. There are good conditions, but they must stay in Russia to live, which has discouraged the enthusiasm of many Chinese men. do you know? China cannot have dual nationality, and in recent years, the government has not supported Chinese people to join other nationalities. For example, if some actors have joined other nationalities, the government will prohibit them from performing or endorsing in the country again. Does this happen in Ukraine?
do you know? Raising children in China is a huge expense. Although the state encourages people to have more children, young families cannot afford the cost of raising children and choose to have only one child. In China, people jokingly call children: four-legged gold swallowing beasts. Little animals that eat money, haha. How about Ukraine?
I made an appointment with my teammates to play football last night and I was very happy. After that, I went to the restaurant to eat with two teammates and drank three bottles of beer. I now control my drinking, not more than three bottles, which is not good for my health. What do you think of the three bottles? Does it need to be reduced? I listen to you, I need your true thoughts.
I look forward to our private exchanges. I can share more photos with you so that you can understand China more truly and the environment in which I live. Do you know the photos of the website? That was when I was as old as you. It was already 8 years ago. Do you think I should have a beard?
I wish you success in your work, and I wish you a happy weekend in advance.
Hugs
靖  ');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x31492B8731C5416AB7A4821C420EDC96, '
Hi sweet  Ralf,  We have the real autumn weather  with a very bright sun and no wind! It is very lovely and pleasant…  near +10 C. Let’s go for the romantic walking in the park tonight such as real lovers he he he 
Ralf, I guess that kind of music for dancing depends on what kind You are going to dance at that moment... slow, quick, relaxed... I like to dance by different kind of music and it depends on my  mood
I have already finished my working day and  I need some glass of wine and comfortable bed at this moment. And also your healing passionate kiss... How are you going to take care about me? would you like to do the relax massage for me or take the warm bath tub?  May be you would like to take any herbal tea for me and hug me so  tenderly and  strong that I feel myself such as for the "stone wall" 
Just the several words about my day… It is another busy Wednesday I have had a lot of work this morning.I have got up very early today because I must do my working tasks  to  12  afternoonand now I can freely go home. 
Ok, I must go and wait for my evening letter also”)
I have so playful and romantic mood today What is about your mood?
Have the great day 
Julia');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x328A7D3612074419B5D571324C941CE5, '
Hola preciosa me gustas mucho, quiero vivir contigo para siempre, soy de antigua Guatemala, conozco bien mi ciudad, con muchos lugares hermosos que conocer, seré tu guía personal, eres lo mejor qué me ha pasado, listo para el matrimonio, creo en la familia, hogareño fiel, honesto, disciplinado, muy activo en la Habitación, déjame hacerte feliz, espero por ti.');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x33AA2BD5435642E6B0F609540F677D2A, '
Hello, my dear princess JULIA!!!
I am very happy to see your letter full of feelings, warmth and love for me, beautiful and distinguished young woman, you made me the happiest man in the world, I also have feelings for you. Feelings of love and love clean and unconditional for you ..! Pure feelings of love and mutual respect, admiration and gratitude !! You are a goddess of pure beauty and love and a good and loving fairy, whom any man would like to love and worship. When you read my letter, I want to smile and feel my attitude towards you and the sincere and pure love I feel and have for you!
As we communicate with you, you will become very dear and close as a woman and lover, but also as a confidant, who inspires confidence and elegance, brilliance and good mood. You have become a very important person in my life and with each of your current and future letters, you occupy more and more space in my heart and no other person takes place in my heart than you and only you, the beautiful and divine goddess. . . Now you are an integral part of my life, of my future and I will fight to the end for our relationship, no matter how small the obstacles will be at some point. I am thinking about our relationship and I hope to create a happy future with our loved ones and with them or, if necessary, alone, because we are brave and responsible, sincere and dignified.
Each of your current and future letters gives me a thousand smiles on my face and makes my heart beat very fast, and when I write to you I am inspired by a divine revelation. I believe that destiny and God worked to cause us to converse and intersect in the great universe created by God. My princess and girlfriend, this is not a game, I am a serious person and I will never make you suffer, if you are faithful and faithful, respectful and worthy !!!!
I am distinguished, faithful, respectful, convinced of family and worthy !!!!
Please think positively and believe that what I am writing is from the heart and that in our love story, which will soon be a reality, everything depends only on us and God''s help. , please trust me and my sincere feelings and without making labels towards you, good and beautiful fairy ... My friend and love, I say with my hand on my heart, that I call the truth and only the truth and In letters to you, they are completely honest. I feel that my heart beats more often when I read your letter or future letters and you have an overflowing spiritual energy and sincerity. My soul tells me that you are the cutest and best man in the world, I feel it with my heart and it deserves all the good in the world. I want you to grow spiritually and feel what pure love means and to be pampered and loved by me like you never were, the beautiful and distinguished princess. I adore and love you indefinitely, my princess. I''m not afraid of your revelation, good and beautiful fairy. This is also strange to me, but I swear that my feelings for you are real and time will tell what is the truth in my feelings for you, my girlfriend and my beautiful princess. In your big and beautiful eyes, like the clear sky, your soul and your love are mirrored, you are an extremely beautiful woman and she deserves all the good in the world. When I think of you, I become the happiest man in the universe. And I want you to feel like my heavenly and unique princess.
In my opinion, because they have experience, it is to be loved and to love and adore you, if you want to be the first, I agree.
I will be tender with you and you will be happy and fulfilled in a relationship with me, because I am tender, educated, I have life experience and honestly any man would want a beautiful young woman like you and who is superlative.
Do you want to be together and love each other, do you want to be my wife?
My heart and soul need care and love, love and purity from a girl like you, who is very beautiful, with a beautiful body, eyes are like the clear sky and sensual mouth and soft and velvety lips.
Do you want to be together and act now and come to you in Ukraine, KIEV, RIVNE or wherever you want, and see that I am an elegant man, who respects women and loves them, who is polite and understanding and who loves all women very much. especially you that you are a virgin !!!
You want me to make love and introduce you to the secrets of love, to know every particle of your body, from the tip of your feet to the tip of your beautiful princess head !!!
You deserve to be loved by a man who loves and respects you, I will love you and you will be your beloved husband and that together, you have a beautiful and united family.
I am an honest man and I will love you and respect you indefinitely ...
I adore you little and beautiful princess and I want to be together as soon as possible, do you agree?
Do you want to be my girlfriend, my confidante, my wife?
If you want to talk in private, I agree and if you agree, I can request the data about you and together we try to create something more serious than virtual communication!
I am an honest man and I will love you and respect you indefinitely ....
I adore you little and beautiful princess and I want to be together as soon as possible, do you agree?
Do you want to be my girlfriend, my confidante, my wife?
You are everything to me, my sun and the woman who will love me as I will love her, with sincerity and food, with mutual respect.
I adore you beautiful princess and I want to be together.
I look forward to your reply, my beautiful and gentle friend !!! With love and affection, GABRIEL.
Looking forward for your answer! I wish you a pleasant day, I will be mentally and spiritually with you .. Hugs and kisses ... Gabriel!
PS Superb, elegant, interesting, distinguished, special and bright. I would definitely like to meet a special young woman like you.
With chosen consideration and much admiration University Professor, GABRIEL University of Craiova, ROMANIA!!!');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x361D3683AD0A4636BBCEC6063E9E9673, '
My dear Julia, I hope you have a good weekend. It''s windy here, so I choose to stay at home.
I miss you, so I went to read the first letter you wrote to me, and I wanted to find out what attracted me. Maybe we have the same values ​​for love. Perhaps your disappointment with Ukrainian men is the same as my disappointment with Chinese women. Maybe it''s just that I see something different in your eyes.
This is a lazy weekend and I have almost no plans other than going downstairs for a walk. I can only watch TV shows to kill time. I try to ask my teammates to play football together, but only one person has time. I think I need more TV shows today. Of course, I also do some housework. I don’t want to cook alone, so I buy pies downstairs to eat. What about you How was the weekend?
I saw you saying you were learning English, how is it now? Chinese English is a compulsory course, I have studied for 10 years, of course, more for exams. But I can understand and speak some simple sentences. When I was working in Beijing, I also encountered two foreigners who asked me directions in English. This is the rare opportunity for me to use English. I have also taught myself a bit of Russian, but I find it difficult. I can only read letters. I only know words: Hello.
Is the weather warmer there? I think the weather will get cold earlier this year. Because this summer is obviously cooler than before, I think it will be colder in winter. I also need to do some preparation, just like a bear preparing to hibernate.
I wish you a good mood.
靖  ');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x36B8860B35754F7CA1D8D3754A3D95DF, '
Dear Julia, I think we need a chance. But I don''t like it here, every letter will be scanned by the website. Would you like to communicate by email? If you can, please reply me yes.
Hugs
Ralf');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x384832E97DEA4773AB141EBD3542D716, ' My Julia,

I''m glad to hear that you missed me t... ');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x3B10649CC248403792DDDB0F292560F3, '
MY RALF,  LOOK INTO MY EYES AND MAYBE YOU WILL SEE THERE YOUR HAPPINESS? Your lady Julia is waiting for the first step from you;)) How are you doing here?
Dear are you ready for your life''s great journey called love? I am… and I hope it starts here and now! Smile
I will be glad we will use this chance to know each other better! Hope my letter will catch your attention! 
I looking to meet a person with whom I can build a long-term relationship,and who will be reliable, caring, and loving as we walk through the rest of our lives side by side. Of course I am not talking about  Ukrainian man, as they are all liars, dishonest and looking only for a one night relationship, they are not loyal because we have so many nice and beautiful, talented and intelligent ladies... But I don''t want to be  a doll for a silly games,  I do value loyalty and don''t want to have broken heart! I know, what I want from life - I appreciate family values. Why you are looking for the woman abroad? How about local ladies?
For me - the creation of family is a not temporary phenomenon, it is - something steady. I''m searching for friend, husband, partner, companion of life to make you and me happy and to be for you true and happy woman! That is why it''s very important for me to find the husband of my heart, because life is empty without Love and beautiful feelings! I am looking for such man with the qualities you have caring and loving, reliable and understanding. Do you have such qualities to make your wife happy?
It is  so interesting to learn another culture and language (I am in process of learning English) and enjoy the foreign customs. Don’t ruin my hope to recolate in your country and be happy with you, because my place is near my man! I wish you have a great eager to know me better, to reveal my personality and hope life have prepared only pleasant surprises for us) I want to be your best surprise in life....Let''s use our chance!!!!
I don`t want so much... just to be happy. 
I want to be happy I mean really happy again, and see my man happy too.
I really wish you a nice day Hope for your answer soon,
Julia');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x3CF439DB7F5545C88FB145E196BB90DF, '
I welcome you warmly. At the beginning I wanted to tell you that you are very beautiful. 
I would love to meet with you if you want. I would like to start a family ... 
But I must warn you ... I am very passionate haha Smile (I was not physically with a woman for a long time)do you want to check? Smile.Does not tolerate violence in a relationship. There should be love, passion and understanding in the relationship. 
People in a relationship should support each other and be with each other for good and bad.
I am 38 years old and I live in the beautiful city of Świdnica (voivodeship dolnyśląsk,next to the city of Wrocław) in Poland,
I like the animal, I spend my time actively ... I like good cinema and I also read a lot.
He often relaxes in the garden with music and a barbecue.
I also like traveling, small and big. 
I have been to the Czech Republic, Austria, Italy and Germany. Venice is not as beautiful as in the movies Smile)
The city where I live has 60,000 inhabitants and is very beautiful. 
There are a lot of greenery, parks, and there are a lot of forests aroundIf you want, check it on the internet Smile). 
Perhaps you will meet them personally.
I love children and I would like to have them my own ... maybe with you.
greetings and kisses. Marcin');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x3E5C5DBF05794EA9960E6753D685DA2D, '
My dear book, Julia, I am very happy to receive your reply in a warm afternoon. I just finished washing my clothes.
Perhaps it is the disappointment of the opposite sex in our own country that makes us full of desire for a foreign country. Have you ever left your country? Have you ever thought about the feeling of being surrounded by Chinese people? They speak the most difficult language in the world to learn. I think only the strongest love can make you determined. right? We still need to refuel.
Yes, it is not easy to learn new knowledge at work, because I have similar experiences. Maybe it''s because you lack a qualified teacher. Of course, I can only be a Chinese teacher to show you the charm of the most difficult language. And in exchange, you can be my Russian and Ukrainian teacher, shall we deal? hah
Even if a lonely person lives in a warm house, his heart is still cold. When two hearts are together, they are not afraid of anything, right?
I am glad that you like the example I gave, the lady book. Of course, I would prefer you to be a romance novel. Maybe I can read different kinds of love. Arbitrage, I don''t quite understand, is this the name of a movie? Or a book?
I am actually not a person who enjoys life very much, and I have no need to be truly happy. In this regard, you can really be my teacher. But I think this requires a real experience, and writing letters is difficult to achieve. Now we can only make a wish that the virus will leave soon and the world will return to normal. Now, you can make a plan for us to meet on the first day. When we can meet, we will make an appointment according to this schedule. what do you think?
The isolation period in China is relatively short, about two months, and more importantly, there are no patients in my hometown, so it does not have much impact on me, which can be understood as paid vacation. I think the financial habits of Chinese people during the isolation period helped a lot. do you know? The Chinese people''s consumption concept is relatively conservative, and we will choose to put the money in the bank instead of spending it every month. Therefore, even if the city is closed and the residential area is closed, some people still lose their income, but we have bank savings that can help us to persist until the city recovers. Is it the same in Ukraine?
I am very happy, you go to visit your parents during the holidays, and so do I. In fact, our parents don''t expect much from us, we just accompany them more, right?
You know, I have a daughter who is 6 years old. Elementary school started in September. I want to know how you think about this, do you have experience dealing with children? She is simply a little witch.
Good luck with your work
靖');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x3F976F1142E440BE9AEECAB9BD5B25FF, '
JING, YOUR GIRL IS REALLY FREEZE WITHOUT YOUR HOT HUGS…The cold and windy Wednesday  is coming. I am very happy because I have started my working  day successfully and did a lot of things  before afternoon. But we have the low temperature at the office place and I am dreaming to cover my favorite blanket and enjoy the hot tea with cheese cake he he eh your dreamy girl
How about the weather in your city? The weather is rainy now and it is winding very strong. If  the weather changes till evening,  I will go to the centre of my city –  to walk there and to see very famous modern restaurant Manhetten.  This restaurant is a mix between a history museum and a pub and is unlike any restaurant. I have never been there but many people who visit my city recommend to visit and to feel the atmosphere of that  years. It will be our first meeting there when You come in Ukraine.
Jing, I am dreaming about us….  I can’t wait for you to be preparing meals here for the two of us. I will be working in the kitchen with you.  If I am wearing a kitchen apron (open back) only or am wearing one of your t-shirts. We will have a GREAT time in the kitchen.  We will have lots of great times together. You and I are just as playful as each other. That is  fantastic! Do you want to cook food with me?  Who is the best nature cooker:  man or woman?
Lots autumn hugs .........
Julia');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x426460975E8A47A594479DA5270897F5, '
Yes Jing, I want to be your book and you can read me every day You can enjoy an interesting topic and discover some new facts for yourself constantly step by step Yes I like this idea I guess that I can be some detecive story or passionate novel about two very passionate lovers "Julia and Jing. 
Arbitrage." What do you think about this name?
Yes I am in process of learning howto enjoy the simple things. Now I try to understand and read some important facts about this thing It is very cute topic Yes I will be your teacher in this question I have some time before our meeting and I will teach intensively this joy and satisfaction... 
What an interesting topic we  have to discuss
Did you notice any changes in your personality during thisquarantine''s time?
waiting for your letter impatiently,
Julia ');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x43016B715DC2437EBE2240F6F903FE87, '
Hola preciosa me gustas mucho, quiero vivir contigo para siempre, soy de antigua Guatemala, conozco bien mi ciudad, con muchos lugares hermosos que conocer, seré tu guía personal, eres lo mejor qué me ha pasado, listo para el matrimonio, creo en la familia, hogareño fiel, honesto, disciplinado, muy activo en la Habitación, déjame hacerte feliz, espero por ti.');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x491DA8E2CA3E46658D58343FE0975ABA, '
My lunch time with you Jing  Yes I support your healthy style of life and yes I am ready to wake up early and go to bed at 9-11 pm  because it is nessecary for our active and productive style of life. 
Yes my personal gardener, I will be always younger than You It is a big bonus in our future harmonious relations
We have a high level of virus cases but it my city it is a calm situation right now Yes You are right We are in a good position at this moment  
My salary is near 10 000 hrn for 1 months. I hope that You will find a good comparison from the level of your country 
We don''t have an official medical insurance in Ukraine but it can be available in the private structures It is not very popular in Ukraine but I know that in Europe it is neseccary if you want to have  a good treatment
Do You prefer to stay with you children at home or go to work??? ho ho ho Yes it is enough  difficult to stay with the noisy children 24/7 Especially when you need work online, for example What is your opinion about this situation?
I am waiting for the news about your wednesday I hope that You are healthy and happy and of course enjoy your life Am I right?
I am waiting for your news,
Julia');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x4ACA1FB46D57453BB678DFB1F1EBB7B6, '
убава девојка ');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x4C8619565C234AA390768217150C3C25, '
My dear lady Julia, it''s time for my breakfast, I think you are still dreaming, and I hope you don''t have insomnia anymore.
Have you ever thought that I am a Chinese, but my name is English, which is not the result of translation. Chinese schools require students to learn English, so the first thing to start with is to choose an English name for yourself. Can you understand? Just like the network name.
I hope you know my Chinese name Jing. This is the name my father gave me. It means peace and quiet. I think this is very similar to my character. I don’t like noise. I like quiet. At the same time, I also Don''t like talking loudly, don''t like quarreling. I hope to tell you this will enable you to understand me better. Can you tell me the story of your name?
I think you must be very busy these two days. It is the weekend now. I think you can have a good rest and I will be with you here.
I discovered an interesting thing. Ukraine has opened a visa-free service for Chinese citizens until early 2021. However, due to the epidemic, Ukraine’s borders are closed and no Chinese flights can enter. Is this contradictory?
Speaking of the epidemic, I saw on the Internet that there are still many patients in Ukraine. How is your city? I hope you take personal protection when you go out. This virus is afraid of high temperatures, and the weather is cool in autumn, and the virus may spread again. I have not been diagnosed with a patient for several months, so except that I need to wear a mask when I go to public places and take buses and trains. Others have returned to normal.
I haven''t received your reply for three days. I want to tell you that I miss you. I downloaded your photo album to my phone. When I miss you, I can turn on the phone and see you. Your smile always calms my heart.
Have a nice weekend.
Jing');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x4DC646EA753E43789EF43CC42C7FA78A, '
My dear Julia, I am glad I got your private email, I think this will be a new start. right?
I emailed you, hope you can see.
Give you a warm hug
靖');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x4E2345A224A74C87939F0F2916D4EA2B, '
Dear Julia,
thanks for your nice and trusty letter.
You are certainly a beautiful woman and certainly more than just a dream woman for many men.
I think, each of us has stored in his subconscious a picture of his dream partner. But when the reality from our imagination far deviates, there is no chance for a common ground.
I''m very sorry, but I want to be honest with you.
Have a nice day
Alexander');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x506F7D3BFB954614812E0757B6D1B9F6, '
Yes Jing, I also hope that it will be a new start and we can try to do it together
How is your Monday? I wish You a great day and new start of the week
We have a very rainy weather and I would like to sleep
no work but just sleep
I am waiting for your news,
Julia');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x5583BAC0615C4606BDEAE7F5AB8BA239, '
Yes Ralf, I can try to use this chance in private email because I really like You I am happy that you answered me It is very important to try and don''t loose our happy chance "
waiting for your serious respond
Julia');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x57DBADAA080C4D94929B4B672CA52ECC, '
jose , I am dreaming to live in Guatemala. antigua guatemala is a perfect place for a family''s life. Don''t You agree with me?I looking to meet a person with whom I can build a long-term relationship,and who will be reliable, caring, and loving as we walk through the rest of our lives side by side. Of course I am not talking about Ukrainian man, as they are all liars, dishonest and looking only for a one night relationship, they are not loyal because we have so many nice and beautiful, talented and intelligent ladies... But I don''t want to be a doll for a silly games, I do value loyalty and don''t want to have broken heart! I know, what I want from life - I appreciate family values. Why you are looking for the woman abroad,? How about local ladies?Your astrological sign is Pisces. You have a very good features of the character for creating a strong family Let''s try this chance, jose ?It is so interesting to learn another culture and language (I am in process of learning English) and enjoy the foreign customs. Do not ruin my hope to recolate in your country and be happy with you, because my place is near my man! I wish you have a great eager to know me better, to reveal my personality and hope life have prepared only pleasant surprises for us) I want to be your best surprise in life....  Waiting for your serious answer, dear jose Julia
');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x5B01170DE88C4705B86BF1FD4F75C399, ' Julia

Thank you so much for your beautiful lett... ');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x5B370FEC269C4B38A0EF3845BB7D2AF4, '
My dear Julia, I am glad I got your private email, I think this will be a new start. right?
I emailed you, hope you can see.
Give you a warm hug
靖');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x5BC06A21BB2E431FA4A9AC482161242F, '
My dear Julia, the first very important thing, eating breakfast is a very important thing for health. Promise me that you need to help me take care of myself now. For three meals a day, breakfast is the most important, followed by lunch, so many Chinese eat very little for dinner, perhaps just a bowl of porridge.
I want to know your work and rest habits. I usually wake up around 6 in the morning. Although I have an alarm clock, I usually wake up before the alarm clock. Can you do it? If I have time at noon, I will take a nap. I usually go to bed between 9-11 at night. The Chinese believe that early to bed and early to rise are good for the body. But many young people are not like this. They have many entertainment activities at night, such as bars, KTV and so on. Is it the same in Ukraine?
I am very happy that you have had the experience of going abroad, I have not, I have not even applied for a passport. I think maybe I should put the passport application on my schedule. It is a terrible thing for a person to be in an unfamiliar country with language barriers. But if you have someone you trust around you, it''s completely different.
I know some knowledge about pregnancy. The strongest pregnancy reaction is in the first three months, but some people will vomit until they give birth due to physical reasons. It is difficult for us to help her in this situation. Perhaps what she needs more is the care and tolerance of her husband, because some pregnant women will become grumpy. Maybe you can learn something about this from her. I hope everything is well for her.
Because of translation reasons, I don''t quite understand the dishes you recommend to me. But this does not affect my expectations of it, because you promised to make it for me. The people who live in my heart cook for me and they must make delicious food. right?
I know that the woman who is favored by her husband is the most beautiful. And you will always be younger than me, right? Of course, I am honored to be your personal gardener.
I know that Ukraine’s economy is worse than China’s. China is better because the virus is controlled within a very small area and 99% of the area is safe. But people in your area face difficult choices, risk being infected, go out to work and make money, or stay home and starve. I feel very lucky. I checked Ukraine’s epidemic news on the Internet. There are fewer patients in your city. This may be the only good news right now.
Would you mind telling me your salary? Let me start by saying that my salary is about 19,000 in hryvnia. Isn''t it that small? And I also need to pay insurance, about 8000. Although this has increased my pressure, but I think I need it. Because the current medical expenses are terrible, do you know? There is no free medical care in China, so the expenses must be borne by myself, so I chose to prepare a medical insurance with full reimbursement for myself.
Yes, parents need more company, and sometimes work does not allow us to have our own time. This is a dilemma. This is the frustration of life, we can only do our best.
I am very happy that you have experience in taking care of little witches. Maybe it is more difficult for Chinese children to take care of. You have to be mentally prepared, haha. do you know? In the two months of closed cities in China, many parents were driven crazy by their children. They would rather go to work than stay at home with their children.
Yes, as the temperature drops, the epidemic will come again, so I hope you can protect yourself. I know you are afraid of the cold, and I am also afraid of loneliness, but now I can only accompany you through the Internet. I confirmed today, and I can apply for your personal contact information from the website by writing another letter. Then maybe we can talk in a more flexible way. Is this good news? If I can, I will be able to leave this website in the future and talk in our own way. do you know? I receive a lot of letters every day, I need to reply and reject them one by one, telling them that I have found my girl and I am tired of this process. I hope you understand me. After I leave here, I can concentrate on reading my book, right?
It''s raining here today, I hope you have a good weather.  
靖');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x5BF4EF37FD7A43A188F95CB22DC8A4A4, '
Dear Julia, first of all I want to apologize to you, I have been communicating with the webmaster. Maybe I don’t understand the rules, we need to be here until I open your 15 letters. Sorry for keeping you waiting for me for so long.
We are the same, I cherish the opportunity we can communicate, maybe we will have a happy family in the future.
do you know? When I saw your picture for the first time, I was attracted by your smile. Your smile is pure and can heal my lonely heart. But at that time I couldn''t contact you, but things quickly changed.
Chinese people rarely take a bath in the morning, but the habit is not absolute. If it''s with my lover, I think no matter what you do is a joy.
Insomnia is usually not unreasonable, so finding the problem and solving it is the most important thing. I had a similar experience. I used to sleep only two hours a day, and I lost 5 kg in a week. I am worried that insomnia will harm your body.
In China, few people at my age can dance because I didn’t have a dance hall when I was young. I want to lose weight. I think staying in shape is also a way to stay healthy. But I am a little lazy, maybe I need someone to supervise me. Will this person be you? I like listening to music, but I don''t know what kind of music is suitable for dancing. Do you have anything to recommend to me? Although we can’t dance together yet, I can try your music first. You like dancing. I think your body must be very flexible. Although slim, you should have good strength in your body.
One thing I want you to know is that the opportunity here is very precious to us, so you don’t need to thank me, maybe I want to thank you, because you wrote to me in the year I left. Created an opportunity for us one year later. Always saying thank you will keep us from being really close.
Can you tell me more about you? I want to know more.
Hugs
Ralf');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x5C7B693C39F84B5C94ACF098FC81C618, '
Jing, I don''t know that song But it is very wize Love is close to us and I am sure that we will use that perfect chance yes internet will help us Because we are far from each other)
I like to sleep with another person but ONLY with my close man. No relatives, no parents. Just the man which I have the serious relations. I guess that You have the situation May be I am wrong
Yes of course I will cheer you on Wow, I see that you are very hard-working man and You want to achieve a lot in this life Yes I am proud of you that You want to change something in the positive side)  
I know that foreigners can be the victims of some unhonest peoples in Ukraine, but it is not only Chinese peoples. I hope that You will be in safe position when you come in Ukraine, because you will have a guard Julia 
yes I  heard about some spam and unhonest situations with the foreigners but it is not so often. Time to time may be...
I don''t know about the extra fee in the airport, but I guess that it is not a true.
Yes we will try to communicate in private email. 
Honey, I need continue my working process 
wait for my evening letter
Julia');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x60487859B3E84C368B1DBBA5C5F9C55D, ' 
Hi Julia, my name is Marco, mine was very please... ');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x60EE82CD5E584E808D3905FC7AF6DDCE, '
Hi 
Check your email when you get a moment. 
Thom  ');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x6290A10C3ABD4761A3D589E054B4DE04, '
Good evening my Julia, 
It sounds like a beautiful day. Too bad it''s raining here. I would love to go on a picnic. Warm hugs and passionate kisses? It looks like I need to practice those kisses with you  
A romantic place? I think where ever I am with you is romantic. 
I really don;t have specific routines for wednesday. Wake up, take a shower, eat some breakfast and go to work. Come back home, take another shower, watch tv and think of you. 
What did you do today? anything happen you want to share? 
Your love, 
Alex');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x67849A8F20C54829AAB6796881E55805, '
Hola, gracias por interesarte en mí y saber algunas cosas más, soy de PERU, región Junín, Provincia de Huancayo, soy profesor, me gusta las cosas serias y correctas, llevo en mi alma y ser, los valores de antaño, no soy perfecto , pero sí muy sentimental y sincero, no busco juegos  o placer sino una compañera, alguien amar por siempre y para siempre, cuidarla, respetarla, engreírla , protegerla todo lo que ella realmente debería de tener, y para mí, solo le pediría que me ame solo a mí con todo su corazón y que sea mi musa (mi inspiración o motivo) y si hubiera algún problema o alguien en su vida, o algo va mal que me diga, aunque las verdades son dolorosas, que sea SINCERA y de mi parte ¡Confía en mí y lo veras!, no te decepcionaré, me gustaría algún día viajar o conocer tu país, pero por diversas razones no puedo por ahora, quizás algún día y solo iría por ti a verte; veo que por ahora la distancia es obstáculo para nosotros, pero si dos personas se aman , la distancia se hace corta, ¡No sé si esto es la manera por correspondencia, pero es un paso!, estoy intentando salir adelante con ayuda de DIOS, poco a poco, las cosas para mí son difíciles pero no me rindo o me doy por vencido, algún día tendré mejores oportunidades para darle una vida de ensueño a mi futura esposa e hijos y que no le falte nada, es por eso que es una de las razones que no podre escribirte seguido, porque trabajo lejos, en una provincia de Chanchamayo (selva) y es lejos y no hay internet, ten paciencia conmigo, no sé si te importa la riqueza o las cosas lujosas, pues lo entenderé; yo valoro muchísimo los sentimientos, los valores y la actitud de las personas y confiar aunque te paguen mal, las cosas materiales se desvanecen, pero si tener lo necesario y algunas comodidades, mi corazón esta solitario y tiempo solo, pensando en encontrar algún día aquella Dama que se enamoraría solo de mí y yo de ella, solo de ella, casarme con ella y servirla y q me ayude, compartir muchas cosas y hacer locuras por toda nuestra existencia, aprender del uno y lo otro, etc; sé que eres hermosa, veo en tus ojos: dulzura, delicadeza, sensualidad, feminidad, pero hay algo más dentro de ti, y me gustaría muchísimo conocerte más, cariño. BUENO CUIDATE MUCHO, BEZOS Y ABRAZOS A LA DISTANCIA CON MUCHO CARIÑO,DE FERNANDO CORDOVA RAMOS…..');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x67C9A845EADB4CCC8B29B62C572BF510, '
Jing, I am going to continue answer your questions because now I have another free minutes during the intensive working day
yes I agree that we can make a plan for the future meeting and dream about the perfect meeting 
yes we also have the difficult financial situation in Ukraine because a lot of peoples lose their income and they need so some extra work to ear some money for life. But I guess that it will be more difficult when the winter is coming and the second wave of quarantine starts 
I have some bank savings but it is very little account. I have a  low salary and a lot of necessary paiments 
Our parents just want to communicate with us more and more because we are very buzy in the modern world and even don''t have a nessecary time for warm talk during the crazy working weeks
I like children and I had some experience with them several years ago. I was baby sitter  I hope that your little Princess will like me very much 
Honestly, I really feel sad about the coming cold autumn and winter time. It will be an empty home wtihout the real warmth and tenderness... Do You have the same feelings? 
I am waiting for your news
Julia');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x68A986C744894B648E64410A881B92EB, '
Marcin, I am dreaming to live in Poland. Świdnica is a perfect place for a family''s life. Don''t You agree with me?I looking to meet a person with whom I can build a long-term relationship,and who will be reliable, caring, and loving as we walk through the rest of our lives side by side. Of course I am not talking about Ukrainian man, as they are all liars, dishonest and looking only for a one night relationship, they are not loyal because we have so many nice and beautiful, talented and intelligent ladies... But I don''t want to be a doll for a silly games, I do value loyalty and don''t want to have broken heart! I know, what I want from life - I appreciate family values. Why you are looking for the woman abroad,? How about local ladies?Your astrological sign is Pisces. You have a very good features of the character for creating a strong family Let''s try this chance, Marcin?It is so interesting to learn another culture and language (I am in process of learning English) and enjoy the foreign customs. Do not ruin my hope to recolate in your country and be happy with you, because my place is near my man! I wish you have a great eager to know me better, to reveal my personality and hope life have prepared only pleasant surprises for us) I want to be your best surprise in life....  Waiting for your serious answer, dear MarcinJulia
');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x68FF9210B36045CE926F2BD2BD6FC92B, '
Yes Jing I also know that before and after heating is the most difficult period Do You have a good mood? Because I feel a little depressive because of rainy and cold weather Any antidepressant you can recommend me? 
Wow I am happy that you like our idea about the tasty food together: cooking and eating of course great idea Yes I will grab your stomach and your heart also Yes yes yes
Please tell me more about that great festival I don''t know a lot of facts about it. Yes I can imagine it as filled bread But I need more information please tell me more
Jing, it is my lunch time and I am going to spend it with you
Are You buzy or lazy now? I hope that You are relaxed Am I right?
Julia');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x69993C68222C450BB676C9CE899A6764, '
My dear lady Julia, our weather is the same. It rained on my side on Monday and Tuesday. The weather became cold and I need to wear a jacket. I think your dress is not suitable. As the weather changes, we will become bloated, and your good figure can only be hidden in your clothes. Before and after heating is the most difficult time period, so I prefer a warm bed or sofa. I''m sorry I can''t help you warm up now, I just hope my letter can bring you a bit of warmth.
I am looking forward to it, you have chosen the place where we meet for the first time. But I think we are more likely to meet at the airport for the first time. I really don''t have much confidence in my foreign language. Maybe I need my lady to wait for me outside the airport holding a sign with my name. Haha
There is a saying in China: If you want to grab a person''s heart, you must first grab his (her) stomach. I think it''s right. Maybe you can be a chef, and I will help you by the side, and you will cook me a hearty Ukrainian meal. The kitchen and dining room will leave us with fond memories. Of course, I can also admire your beautiful apron.
In half a month is the traditional Chinese festival, the Mid-Autumn Festival. This year is quite special. The Mid-Autumn Festival is the same day as our country’s National Day. I think I will have a ten-day holiday. Are you envious? Do you know the Mid-Autumn Festival in China? This is a holiday for the whole family, we will eat moon cakes together. From the name, you can know that moon cakes are round, like the moon, with various fillings inside. You can imagine it as filled bread.
I don''t think you know which photo is my favorite. I will reveal the answer for you. It is the second photo in your album. I like your smile, your dress, and your posture against the wall. I think everything is perfect.
It is 6 pm, my Wednesday is about to end, and you should be noon, I hope you can go to the city center today as you wish.
Many autumn kisses
Jing  ');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x6A7DC7440EA14E7A95927778E74004E1, '
My dear Julia, I am glad I got your private email, I think this will be a new start. right?
I emailed you, hope you can see.
Give you a warm hug
靖');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x6B63BCF3499B4DFC97D5D94F0CD0E17B, '
');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x70473742D89B4AEE8476BB9BF203E417, '
Hola, gracias por interesarte en mí y saber algunas cosas más, soy de PERU, región Junín, Provincia de Huancayo, soy profesor, me gusta las cosas serias y correctas, llevo en mi alma y ser, los valores de antaño, no soy perfecto , pero sí muy sentimental y sincero, no busco juegos  o placer sino una compañera, alguien amar por siempre y para siempre, cuidarla, respetarla, engreírla , protegerla todo lo que ella realmente debería de tener, y para mí, solo le pediría que me ame solo a mí con todo su corazón y que sea mi musa (mi inspiración o motivo) y si hubiera algún problema o alguien en su vida, o algo va mal que me diga, aunque las verdades son dolorosas, que sea SINCERA y de mi parte ¡Confía en mí y lo veras!, no te decepcionaré, me gustaría algún día viajar o conocer tu país, pero por diversas razones no puedo por ahora, quizás algún día y solo iría por ti a verte; veo que por ahora la distancia es obstáculo para nosotros, pero si dos personas se aman , la distancia se hace corta, ¡No sé si esto es la manera por correspondencia, pero es un paso!, estoy intentando salir adelante con ayuda de DIOS, poco a poco, las cosas para mí son difíciles pero no me rindo o me doy por vencido, algún día tendré mejores oportunidades para darle una vida de ensueño a mi futura esposa e hijos y que no le falte nada, es por eso que es una de las razones que no podre escribirte seguido, porque trabajo lejos, en una provincia de Chanchamayo (selva) y es lejos y no hay internet, ten paciencia conmigo, no sé si te importa la riqueza o las cosas lujosas, pues lo entenderé; yo valoro muchísimo los sentimientos, los valores y la actitud de las personas y confiar aunque te paguen mal, las cosas materiales se desvanecen, pero si tener lo necesario y algunas comodidades, mi corazón esta solitario y tiempo solo, pensando en encontrar algún día aquella Dama que se enamoraría solo de mí y yo de ella, solo de ella, casarme con ella y servirla y q me ayude, compartir muchas cosas y hacer locuras por toda nuestra existencia, aprender del uno y lo otro, etc; sé que eres hermosa, veo en tus ojos: dulzura, delicadeza, sensualidad, feminidad, pero hay algo más dentro de ti, y me gustaría muchísimo conocerte más, cariño. BUENO CUIDATE MUCHO, BEZOS Y ABRAZOS A LA DISTANCIA CON MUCHO CARIÑO,DE FERNANDO CORDOVA RAMOS…..');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x714B66E4E0EE486D9D7EE990FF7B578D, '
Manuel, I am dreaming to live in Chile. Villa Alemana is a perfect place for a family''s life. Don''t You agree with me?I looking to meet a person with whom I can build a long-term relationship,and who will be reliable, caring, and loving as we walk through the rest of our lives side by side. Of course I am not talking about Ukrainian man, as they are all liars, dishonest and looking only for a one night relationship, they are not loyal because we have so many nice and beautiful, talented and intelligent ladies... But I don''t want to be a doll for a silly games, I do value loyalty and don''t want to have broken heart! I know, what I want from life - I appreciate family values. Why you are looking for the woman abroad,? How about local ladies?Your astrological sign is Cancer. You have a very good features of the character for creating a strong family Let''s try this chance, Manuel?It is so interesting to learn another culture and language (I am in process of learning English) and enjoy the foreign customs. Do not ruin my hope to recolate in your country and be happy with you, because my place is near my man! I wish you have a great eager to know me better, to reveal my personality and hope life have prepared only pleasant surprises for us) I want to be your best surprise in life....  Waiting for your serious answer, dear ManuelJulia
');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x714F4B19828C4E8492604FE08CDCC755, '
Dear Julia, I am very happy to read your letter. First of all, I want to apologize. I have left this website for more than a year. I only came back here recently, so I am late to reply. I read your letter several times, I think we have something in common, but I am now in contact with a girl, I can not contact several girls at the same time, I do not like this, I hope you can understand. Perhaps, one day in the future we will have a chance to get to know each other.
good luck.
Ralf');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x71C1E3BCD5574EC6AE39D25A33360071, '
My dear ladyJulia, I am very happy to receive two letters from you, which can help me to alleviate the missing you.
My hometown is colder in autumn. I prefer to stay in a warm bed. It is perfect if there is a lover by my side, but you are not there. So you write to me more, promise me?
Regarding the energy exchange you said, I don’t know much, but there is another way of saying it in China. A man represents yang, and a daughter represents yin. The fusion of yin and yang is perfect. So a man can''t stay alone, he must find a good woman like you to accompany him through the road of life, support and help each other. What do you think?
do you know? My hometown is the same latitude as Bordeaux in France, so what are the specialties of my hometown? Grapes and wine, the earliest wine in China was produced in your hometown, do you yearn for my hometown more? It''s just the season when the grapes are ripe. There are many grape picking gardens open now. Many different kinds of grapes can be picked. I want to go with you.
I look forward to your breakfast, although I have no chance to taste it now. But we have one thing in common. We all go to work by bus. Of course, sometimes I choose to walk to work. It takes about half an hour. Walking is also a method of exercise. I think it must be nice for us to walk together.
I can''t imagine the charm of your dress, which might make me intoxicated like old wine. I am willing to be attracted by your charm, which makes me want to know you more.
Speaking of work, what I used to do was to communicate with machines, but I didn''t like it, so now I communicate more with people, finding ways to complete difficult tasks is a very fulfilling thing, isn''t it?
t is a pity that I have never ridden a horse. There are very few opportunities to ride a horse in China. Maybe you can teach me some knowledge. You may be able to teach me in the future, my dear teacher Julia.
Finally, ask a question. Guess which photo I like best in your album? Take a look at me and your appreciation of your charm is consistent? Looking forward to your answers.
looking forward to your reply
With love
Jing  ');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x72406266806A43D2889189CA1368DB2C, '  Hello Julia. How are you? Thank you for message. ... ');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x7304BA1966AF421FA912668800B218E1, '
Jing, If you read THIS LETTER, you will be happier and satisfied because I wrote it with all my heart and positive energy!!! Share with you my BEST feminine ENERGY Do You know any facts about the exchange of energies of man and woman? This morning I learnt the information aboutenergy structure, female and male chakras. It is necessary knowledge for developing the harmonious personality. And of course the harmonious couple…. If You are interested, I will write You  more about this topic in my next letter
We  have so warm and sunny weather and opposite the prognoses of synoptics the weather is really cool and great Ohhh It would be  pleasant to have the great walking with you outside)
I have already started my working day and I am going todo all tasks quickly and finish earlier than usual because my cousin invited me to visit racetrack free tonight. When did you visit it last time, Jing? Are you fond of riding horses? I like this kind of animals  I am very exciting about this… 
Waiting for your news,
Passionate kiss for You
Julia');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x78518B4A67AA4C09B04DC4A0BC53DB16, '
My dear Julia, I hope you have a good weekend. It''s windy here, so I choose to stay at home.
I miss you, so I went to read the first letter you wrote to me, and I wanted to find out what attracted me. Maybe we have the same values ​​for love. Perhaps your disappointment with Ukrainian men is the same as my disappointment with Chinese women. Maybe it''s just that I see something different in your eyes.
This is a lazy weekend and I have almost no plans other than going downstairs for a walk. I can only watch TV shows to kill time. I try to ask my teammates to play football together, but only one person has time. I think I need more TV shows today. Of course, I also do some housework. I don’t want to cook alone, so I buy pies downstairs to eat. What about you How was the weekend?
I saw you saying you were learning English, how is it now? Chinese English is a compulsory course, I have studied for 10 years, of course, more for exams. But I can understand and speak some simple sentences. When I was working in Beijing, I also encountered two foreigners who asked me directions in English. This is the rare opportunity for me to use English. I have also taught myself a bit of Russian, but I find it difficult. I can only read letters. I only know words: Hello.
Is the weather warmer there? I think the weather will get cold earlier this year. Because this summer is obviously cooler than before, I think it will be colder in winter. I also need to do some preparation, just like a bear preparing to hibernate.
I wish you a good mood.
靖  ');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x78D7255BB567490FBBE4965AC7DC24DE, ' Hi Jlia
Sorry, that I replied so late.
Yout letter remained between two eyes Very Happy
If you`re still free ,I want to communicate with you
You are very beautiful and sexy.
I like you very much and I have serious intention
I like a reliable relationship
I am very sorry
I´m active in motocross and I have motocross MXGP Team
Kisses
Mati P.');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x7F7E55654CE740F0B0CDEA0A11D13CE1, '
My dear lady Julia, our weather is the same. It rained on my side on Monday and Tuesday. The weather became cold and I need to wear a jacket. I think your dress is not suitable. As the weather changes, we will become bloated, and your good figure can only be hidden in your clothes. Before and after heating is the most difficult time period, so I prefer a warm bed or sofa. I''m sorry I can''t help you warm up now, I just hope my letter can bring you a bit of warmth.
I am looking forward to it, you have chosen the place where we meet for the first time. But I think we are more likely to meet at the airport for the first time. I really don''t have much confidence in my foreign language. Maybe I need my lady to wait for me outside the airport holding a sign with my name. Haha
There is a saying in China: If you want to grab a person''s heart, you must first grab his (her) stomach. I think it''s right. Maybe you can be a chef, and I will help you by the side, and you will cook me a hearty Ukrainian meal. The kitchen and dining room will leave us with fond memories. Of course, I can also admire your beautiful apron.
In half a month is the traditional Chinese festival, the Mid-Autumn Festival. This year is quite special. The Mid-Autumn Festival is the same day as our country’s National Day. I think I will have a ten-day holiday. Are you envious? Do you know the Mid-Autumn Festival in China? This is a holiday for the whole family, we will eat moon cakes together. From the name, you can know that moon cakes are round, like the moon, with various fillings inside. You can imagine it as filled bread.
I don''t think you know which photo is my favorite. I will reveal the answer for you. It is the second photo in your album. I like your smile, your dress, and your posture against the wall. I think everything is perfect.
It is 6 pm, my Wednesday is about to end, and you should be noon, I hope you can go to the city center today as you wish.
Many autumn kisses
Jing  ');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x7F9C0DA124534F8DB0EF0F6664234646, '
дівчинка, найбезпечніше сісти в літак і прямо зі мною .... ха-ха-ха, у вас є пропозиція, яку не можна пропустити. Я серйозно про це .... тепер вам цікаво (хто цей дурень, який раптом сказав це так) це не золото Я не дурень, але нудно постійно читати повідомлення ... Я цілую тебе, прекрасна дівчина');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x84F86CAB47E8458AAF1047362C120771, '
My dear book, Julia, I am very happy to receive your reply in a warm afternoon. I just finished washing my clothes.
Perhaps it is the disappointment of the opposite sex in our own country that makes us full of desire for a foreign country. Have you ever left your country? Have you ever thought about the feeling of being surrounded by Chinese people? They speak the most difficult language in the world to learn. I think only the strongest love can make you determined. right? We still need to refuel.
Yes, it is not easy to learn new knowledge at work, because I have similar experiences. Maybe it''s because you lack a qualified teacher. Of course, I can only be a Chinese teacher to show you the charm of the most difficult language. And in exchange, you can be my Russian and Ukrainian teacher, shall we deal? hah
Even if a lonely person lives in a warm house, his heart is still cold. When two hearts are together, they are not afraid of anything, right?
I am glad that you like the example I gave, the lady book. Of course, I would prefer you to be a romance novel. Maybe I can read different kinds of love. Arbitrage, I don''t quite understand, is this the name of a movie? Or a book?
I am actually not a person who enjoys life very much, and I have no need to be truly happy. In this regard, you can really be my teacher. But I think this requires a real experience, and writing letters is difficult to achieve. Now we can only make a wish that the virus will leave soon and the world will return to normal. Now, you can make a plan for us to meet on the first day. When we can meet, we will make an appointment according to this schedule. what do you think?
The isolation period in China is relatively short, about two months, and more importantly, there are no patients in my hometown, so it does not have much impact on me, which can be understood as paid vacation. I think the financial habits of Chinese people during the isolation period helped a lot. do you know? The Chinese people''s consumption concept is relatively conservative, and we will choose to put the money in the bank instead of spending it every month. Therefore, even if the city is closed and the residential area is closed, some people still lose their income, but we have bank savings that can help us to persist until the city recovers. Is it the same in Ukraine?
I am very happy, you go to visit your parents during the holidays, and so do I. In fact, our parents don''t expect much from us, we just accompany them more, right?
You know, I have a daughter who is 6 years old. Elementary school started in September. I want to know how you think about this, do you have experience dealing with children? She is simply a little witch.
Good luck with your work
靖');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x85CF7C3CFB3248E7B771E82CBE5C2CA2, '
My dear Julia, the first very important thing, eating breakfast is a very important thing for health. Promise me that you need to help me take care of myself now. For three meals a day, breakfast is the most important, followed by lunch, so many Chinese eat very little for dinner, perhaps just a bowl of porridge.
I want to know your work and rest habits. I usually wake up around 6 in the morning. Although I have an alarm clock, I usually wake up before the alarm clock. Can you do it? If I have time at noon, I will take a nap. I usually go to bed between 9-11 at night. The Chinese believe that early to bed and early to rise are good for the body. But many young people are not like this. They have many entertainment activities at night, such as bars, KTV and so on. Is it the same in Ukraine?
I am very happy that you have had the experience of going abroad, I have not, I have not even applied for a passport. I think maybe I should put the passport application on my schedule. It is a terrible thing for a person to be in an unfamiliar country with language barriers. But if you have someone you trust around you, it''s completely different.
I know some knowledge about pregnancy. The strongest pregnancy reaction is in the first three months, but some people will vomit until they give birth due to physical reasons. It is difficult for us to help her in this situation. Perhaps what she needs more is the care and tolerance of her husband, because some pregnant women will become grumpy. Maybe you can learn something about this from her. I hope everything is well for her.
Because of translation reasons, I don''t quite understand the dishes you recommend to me. But this does not affect my expectations of it, because you promised to make it for me. The people who live in my heart cook for me and they must make delicious food. right?
I know that the woman who is favored by her husband is the most beautiful. And you will always be younger than me, right? Of course, I am honored to be your personal gardener.
I know that Ukraine’s economy is worse than China’s. China is better because the virus is controlled within a very small area and 99% of the area is safe. But people in your area face difficult choices, risk being infected, go out to work and make money, or stay home and starve. I feel very lucky. I checked Ukraine’s epidemic news on the Internet. There are fewer patients in your city. This may be the only good news right now.
Would you mind telling me your salary? Let me start by saying that my salary is about 19,000 in hryvnia. Isn''t it that small? And I also need to pay insurance, about 8000. Although this has increased my pressure, but I think I need it. Because the current medical expenses are terrible, do you know? There is no free medical care in China, so the expenses must be borne by myself, so I chose to prepare a medical insurance with full reimbursement for myself.
Yes, parents need more company, and sometimes work does not allow us to have our own time. This is a dilemma. This is the frustration of life, we can only do our best.
I am very happy that you have experience in taking care of little witches. Maybe it is more difficult for Chinese children to take care of. You have to be mentally prepared, haha. do you know? In the two months of closed cities in China, many parents were driven crazy by their children. They would rather go to work than stay at home with their children.
Yes, as the temperature drops, the epidemic will come again, so I hope you can protect yourself. I know you are afraid of the cold, and I am also afraid of loneliness, but now I can only accompany you through the Internet. I confirmed today, and I can apply for your personal contact information from the website by writing another letter. Then maybe we can talk in a more flexible way. Is this good news? If I can, I will be able to leave this website in the future and talk in our own way. do you know? I receive a lot of letters every day, I need to reply and reject them one by one, telling them that I have found my girl and I am tired of this process. I hope you understand me. After I leave here, I can concentrate on reading my book, right?
It''s raining here today, I hope you have a good weather.  
靖');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x8635C6C2A9584E70AA4F83C37356F91A, ' Marcin:) Yes it is a great chance to TRY this chan... ');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x876FB2EC91404D29B8B0D94EF105EC00, '
My dear lady Julia, it''s 11 o''clock in the evening, and I saw your letter after taking a shower. This is your gift to me before going to bed.
Usually the weather does not affect my mood, I just don''t like going out in bad weather. The weather is getting cold, and I have no better way. I can only suggest that you wear more clothes. Maybe thick clothes can help you.
Regarding the Mid-Autumn Festival, this has been a very important festival in China since ancient times. It is a festival for family reunion. People who go out will return home and be with their parents and relatives. In the past, TV stations would hold evening parties. This year is special. I don’t know if they will be held. There will be some decorations on the street, such as lanterns, which will be lit up at night, red and very festive. Chinese people like to use red to represent joy. For example, New Years and weddings will have a lot of red decorations and red clothes. In China, black and white are usually the colors used in funerals.
The Mid-Autumn Festival has a history of more than a thousand years in China. Ancient people worship the moon, so there is this festival. In Chinese myths, the most beautiful and dancing goddess lives on the moon, called Chang''e. There was only an osmanthus tree and a little rabbit to accompany her. The Mid-Autumn Festival is the best time to admire the moon. The shadow on the moon is like a rabbit. I don''t know if it is the same in Ukraine. If the weather is good, maybe I can take a photo for you.
Moon cakes were originally one of the tributes to sacrifice to the moon, and later became gifts that people gave each other during the Mid-Autumn Festival. I also need to send moon cakes to my parents and relatives before the festival to express my blessings. One thing is strange, the history of moon cakes predates the Mid-Autumn Festival. The current mooncake making technology has made great progress. There are many kinds of fillings, such as sugar, eggs, meat, and even ice cream. Do you really want to taste it?
I am honored to have my letter to spend lunch with you. It makes me feel that I am by your side. It feels so good. Then your reply will accompany me to sleep. I will say good night to you in advance.
My recent work is not busy, so I can finish my work leisurely, and then wait for your letter. Don''t envy me, I don''t have time to rest when I''m busy.
The last question is that there is no concept of tip in China. I don’t really understand why I still need to tip the waiter when I go to a restaurant. Can you explain it to me?
Wish you have a good mood.
Jing');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x88BEB9EF48DB4BAC8BA18B02D2739DDB, ' Hola, gracias por interesarte en mí y saber alguna... ');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x88FF395D4D0948CA8F70973800EE3492, ' Bonjour Julia, j’ai beaucoup apprécié ta lettre, e... ');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x898711F7290F4E6492B174B0D2298801, '
I want to buy apartment in kiev
Can help me');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x8CEE3B686C8E43C79C71DDD4EE45ED25, '
Dear Julia, I''m lying in my bed at home and reading your reply. It''s a great feeling. 
Your introduction is very detailed. In fact, to know your hometown is to better understand you. I am more interested in zoos and may need you to be a private guide. In exchange, I need to introduce my hometown, which is only 200 kilometers away from the capital Beijing. In the northwest of Beijing, it has been the first line of defense against foreign enemies since ancient times. Therefore, the economy here is not very developed, and there are not many historical buildings. The only one with historical traces is the Great Wall. In 2022, Zhangjiakou, my hometown, will help Beijing to hold the Winter Olympics. It''s close to the mountains, so it''s colder in winter than you.
Can you tell me your height? In China, the husband is usually taller than his wife, 10-15cm is the best. So it''s hard for tall girls to find a lover. Will this be the case in Ukraine? My height is 178 cm.
I also have a question, such as you beautiful girl, should not lack pursuers, how can you want to come to this website to find true love?In China, many girls first see betrothal gifts when they get married. Second, they ask their husbands to provide houses and cars. Third, girls need to control the family''s finances. Fourth, they may consider love. Such a marriage full of impurities is not the love I want. Maybe I am an idealist. What do you think?
I usually go to bed before 10 o''clock in the evening and get up at 6:30 in the morning. Going to bed early and getting up early is also a way to keep healthy. what about you? 
I know there is Chinese food in Ukraine. Have you tried it? If so, what did you eat? I''m good at cooking. I can practice your favorite dishes from now on.
It''s a great honor for my letter to accompany you to spend a special Wednesday. I''m going to get ready to go to bed. I hope you won''t have insomnia today.
Hugs
Ralf');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x91192DDC83A7444BA4D44D122DC7D2B1, '
Hey Julia, 
Thanks so much for your letter.  My dream is to be with you this winter too.  Its gonna be so cold being alone again another winter.  I hate the thought of it.  Ive been thinking about this every time I feel the cold.  I too go home every day to an empty house.  No one there to greet and share warmth with. I do believe that next year at some point things will turn around for us. I try to be positive and be optimistic even though it is difficult.
In my family all females work and in most families nowadays in the U.S. it is normal for the wife to work.  Things would be a lot easier with two incomes.  I support the wife working if that''s what she wants to do. I''m glad you are a hard worker.  I''ve known this about you and I think it''s really great. 
It''s one of the many things I like about you.
I need you too my Julia.  I want very much to spend my days with you.  You are everything that I wish for and more. 
Hope you have a nice Sunday.  Ill be thinking of you.  
Yours always
Dave');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x93BCE20E06EB4618AA0910D6F6BF4B45, ' Jose, Yes it is a great chance to TRY this chance ... ');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x955BD03901214012970E3E9C2EDFD7C3, '
Hey Julia,
I am interested in hearing more about the Male and female exchange of enerfys.  I find all of that kind of stuff very interesting too and fully believe in it.
It is a very cool morning here.  I really wish I had you next to me.  I had to turn on the heat this morning in the house for the first time.  I would rather turn on the heat with us hahaha.  I woke up freezing!
I really hope you have a good time at the racetrack.  We have one near here. I stayed there one time.  It has a casino too.  I''d like to bring you.
I always think about you Julia!
Dave');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0x981E93A9B47348D7A23CADA1DD86922D, '
Hey Julia
I was very happy to receive two letters from you.  You are the only one that I want to share these cold autumn days with.  I too have strong desire to be together now.
It''s funny that you bring up monotony.  I have the same strange thoughts all of the time.  Same thing day after day after day.  I''ve thought of driving different ways to and from work for example.  And yes perhaps I''ll need to change around the furniture.  Change is the only way to a different result.  I have the strong need for love too. It will shake up my world and change everything.
Things in New york state and my city are still good.  Everything is open.  The rest of the country is a different story though.  Everything that didnt get hit the first time is now getting hit.  Hopefully a vaccine is found sooner than later.  
I wish you a productive day at work.  I''ll be thinking of you.  
Dave');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0xA34E21EEEFD14070BA28FF99828A17E7, '
My dear lady Julia, it''s 11 o''clock in the evening, and I saw your letter after taking a shower. This is your gift to me before going to bed.
Usually the weather does not affect my mood, I just don''t like going out in bad weather. The weather is getting cold, and I have no better way. I can only suggest that you wear more clothes. Maybe thick clothes can help you.
Regarding the Mid-Autumn Festival, this has been a very important festival in China since ancient times. It is a festival for family reunion. People who go out will return home and be with their parents and relatives. In the past, TV stations would hold evening parties. This year is special. I don’t know if they will be held. There will be some decorations on the street, such as lanterns, which will be lit up at night, red and very festive. Chinese people like to use red to represent joy. For example, New Years and weddings will have a lot of red decorations and red clothes. In China, black and white are usually the colors used in funerals.
The Mid-Autumn Festival has a history of more than a thousand years in China. Ancient people worship the moon, so there is this festival. In Chinese myths, the most beautiful and dancing goddess lives on the moon, called Chang''e. There was only an osmanthus tree and a little rabbit to accompany her. The Mid-Autumn Festival is the best time to admire the moon. The shadow on the moon is like a rabbit. I don''t know if it is the same in Ukraine. If the weather is good, maybe I can take a photo for you.
Moon cakes were originally one of the tributes to sacrifice to the moon, and later became gifts that people gave each other during the Mid-Autumn Festival. I also need to send moon cakes to my parents and relatives before the festival to express my blessings. One thing is strange, the history of moon cakes predates the Mid-Autumn Festival. The current mooncake making technology has made great progress. There are many kinds of fillings, such as sugar, eggs, meat, and even ice cream. Do you really want to taste it?
I am honored to have my letter to spend lunch with you. It makes me feel that I am by your side. It feels so good. Then your reply will accompany me to sleep. I will say good night to you in advance.
My recent work is not busy, so I can finish my work leisurely, and then wait for your letter. Don''t envy me, I don''t have time to rest when I''m busy.
The last question is that there is no concept of tip in China. I don’t really understand why I still need to tip the waiter when I go to a restaurant. Can you explain it to me?
Wish you have a good mood.
Jing');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0xA3DB9F2EAC534D2BA87AF225D2859983, '
Deqr Julia,,
To begin, my name is Marc . I''m not sure why you didn''t see that in my profile, but it is there.  But, Julia...is a beautiful name for a beautiful woman. I am not sure what prompted you to write to me, but, I am flattered that you did. I hope that it was not just cut and pasted like so many that I receive are. It can be difficult to write a personal letter, to someone you do not know at all,, but sometimes, everything
you need to see is in a photo and a few paragraphs. I do not write back to women that write me without using my name somewhere in their letter, since it is often a sign that it was a cut and pasted letter that has been sent to numerous men here. Yours did seem genuine. Both your letter and profile intrigued me. I also have a weakness for a beautiful woman with long dark hair, so, you are touching all of the right spots in me.
I have to be honest, I will always be honest, whether we share just a note or two, or we somehow end up living the dream here, sharing a life. Due to a woman who played games with me here...I haven''t been on this site or responded to anyone who has tried to write to me in many many months..I am surprised that my profile wasn''t buried behind others who have been on this site for a shorter period of time than me, but, maybe you were meant to find me.
So, here I am.
To be honest, when I received an email notification that I had a message waiting for me, I opened it and saw your photo.. not that looks are most important, but, let''s be honest, if there is no immediate physical attraction of some kind, then there may be nothing else that follows. Often, it is the first thing you see.. I was attracted,, and I was curious,, so,, I read the message that you were kind enough to send to me. It was very brief, but it touched a major point and sometimes it may be one thing about a person that initially charms you or turns you off.. You may decide after reading this that you made a mistake and do not wish to communicate any further...(do not think that I am not generous or that I am cheap, since what I am about to say could be misinterpreted but, as you may know, if you do read on and think that I may have a quality that you wish to explore, and we start to get to know each other better, I will have to purchase credits to be able to read your emails to me.
I am not cheap, but I must be careful if I choose to really begin to know someone here. The last time that I did, it quickly became her telling me sad tales of how she was so lonely, that she fell in love with me (very quickly), don''t get me wrong, I belkeve that a .an and a woman can fall in love here, getting to know one another very intimately without physical feelings clouding our judgement.  But, then by the 4th or so letter between us, she began asking me to buy her all kinds of things here. I am the type of man who is sentimental and I take great pleasure in giving gifts from time to time for a woman that I am fond of. I should have known, I should have suspected that when she began to get specific with things that she said she needed (and wanted) I decided to test her and sent her a simple cute teddy bear that this site offers as a gift to send (which, thru this site is really stupid expensive) and, of course, after sending that, she showed very little appreciation. I mean, yes, it was only a teddy bear, but it is the thought behind cute little gifts like that which is most important I feel..once that happened,, she then made up a story about some kind of bracelet that she claimed that her grandmother had given her,, that she had lost,, and there just happened to be one on this site that was exactly like it and she wanted me to buy that for her. Now, I am not a stupid or desperate man that needs a partner THAT bad, and I was able to see right through what she was starting to do. She then told me that she needed a cell phone to replace the one that she had, because she claimed that it was broken or stolen or something, and so on. After I didn''t send her these items because they are not only way more expensive here than going to a store and buying them, but it was clear that I was being played by her. I stopped communicating with her, because it seemed that she was here to see how many items and money she could squeeze out of me, and I will bet she was probably writing to other men, maybe many men at the same time, asking the same things .
My intentions here are pure and I am hoping to find just one wonderful, beautiful woman who, if we are lucky, could be my soulmate, my heart''s heart. It is a long shot, I know, but I don''t have the time or am willing to spend what could add up to thousands of dollars (a lot of money) I believe the Ukrainian word would be грошові суми?
Lastly sweet Julia, I am not in the position to relocate to Ukraine, and hope that if I end up with some lovely woman from this site (maybe you?) that you would be willing to come to me, to live and settle here, to build a life together here. Interestingly though, I have recently checked my family history and my father''s side of my family originated in Ukraine dating back to the early 1800''s. So, I do have Ukrainian blood in me. I have always suspected that I did. I knew that my grandfather came from Russia, but, I was surprised to learn that we went back even further, and apparently my father''s great-grandfather emigrated to Russia from Ukraine around 1855.
I am not looking for a maid or a cook, I have always been able to care for myself and my home. I just want one wonderful, beautiful, loving woman to share my home, my heart, and my life with.
If you feel that what I am seeking is in line with what you also are seeking in a mate, if you would be possibly willing to relocate to the USA eventually if there was a true connection between us, then I would be willing to pursue getting to know you to see what may develop.
If your intentions are honest and you can be patient in the time that may pass for us to get to know one another and until we could be together, then we are off to a good start.
Essentially, everything is set up for the man to make a substantial financial investment and pass a lot of requirements, each also costing much more money before we could simply freely write to or text one another. I am not cheap, I am financially very stable, but I will not make that kind of investment unless I feel certain that there is a woman on the other side who is true and genuine, then I may be willing to take a chance once again.
Anyway Julia, I think you are lovely and I thank you for your interest in me. If you choose not to reply to this note, I understand completely and wish you well in your search for someone special. But, if you think that we could possibly become something, then I welcome your reply and hope you will tell me more. The last thing that I wanted to ask is that if you do write back, please make the notes long, and full of detail. Once again, and I am sorry to keep repeating it. A 2 line letter costs the same as a 4 page letter to open and read.
There is much to get to know about me, I am a truly romantic, gentle, loving man who believes that his special woman could be anywhere in this world...perhaps even reading this note. So, I remain hopeful...
Fondly,
Marc');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0xA463BEB23D7D4AED85AAAF53D81282B1, '
Hello my dear Julia,
I''m glad to hear that and i always feel very comfortable with you too. 
My favorite restaurant is an Italian restaurant called carrabbas.  I''d like to bring you there sometime. I love how they have bread that you can dip in olive oil.  
Both my mothers parents and fathers parents live on the same road.  All of them are still alive except my grandmother on my father''s side.  I was closest to her.  She passed away I think in the year 2000 at the age of 60 from a disease that runs in our family.  It affects the liver and the lungs.  My grandfather eventually remarried.  Yes, both have a harmonious unity.  My grandparents on my mother''s side have been together for 60 something years!  
I would be happy to walk with you today.  I always think of you.  
Have a nice day.
Dave');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0xA878E30004A643F8AA102D5AB3B50651, '
My dear Julia, I know what you mean. Autumn should be the harvest season, but we will feel lost if we have empty hands. But I think this autumn is a special season. Because we know each other. Hope this can change your mood.
My life is as monotonous as yours. This is the test of life for us. We must learn to find our own pleasure from some details. Now, you are the sunshine that illuminates my gray life, so I will bless you from afar until we meet. I don''t care much about the layout of the home. This may be the difference between men and women. I think most men don''t care about such details. But if my lover wants to change, I will actively participate in the design of new plans.
Yes, the virus is becoming serious, and we have no better way. We can only look forward to the launch of the vaccine. I heard that Chinese vaccines will be available as early as November. China is very good. There is almost no virus in the country. Almost 2,000 patients who have been diagnosed have entered China from abroad. China has strict border inspections, which has protected us very well. I think maybe China is one of the countries with the least virus in the world. I feel very lucky, because when the virus first broke out in China, everyone was very scared, but we controlled the spread of the virus very well. And everyone obeyed the government''s arrangements without any complaints. This is unimaginable in many other countries. What do you think?
It''s 10 o''clock in the evening, I am ready to go to bed, looking forward to you walking into my dream.
Also wish you a good dream in advance
靖  ');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0xA8EF12D66A4649709F6732FED7786D98, '
Really ! Thanks for nice letters from you ! I Hope that you say is truth and honest from you , ');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0xA95C23C305BA4367BEA1F1FD1CE1009A, '
Ralf, My lunch time with You I am happy to share my day and exchange the live''s experience and thoughts, ideas 
I like warm spring and autumn best of all I don''t like winter, because I am afraid of frosty weather and strong wind
Let''s talk about the possible future meeting when you come It is too early to discuss this moment now. But i guess that yes You can use translator during our conversation.
Now is it an interesting information about my city. Rivne is among the most beautiful and clean cities in Ukraine. It has repeatedly won prizes at national competitions for city improvement. Around the city there are forests with rich flora and fauna.
It is located in a temperate climate zone. The average temperature in July is plus 18.9 degrees Celsius, in January - minus 3.5 degrees Celsius. The city has a favorable geographic location at the intersection of international highways and railroads. The main industries are mechanical engineering, chemical, light, food, and peat industries.
There are more than a dozen institutions of higher education in Rivne, the largest of which are the National University of Water Resources and Nature Management and the State Humanitarian University.
Rivne is an important cultural center. The city has a regional academic Ukrainian musical and drama theater and a regional puppet theater, a chamber and organ music hall (with one of the best organs in Europe), a movie theater “Ukraine”, a zoo of national importance, 3 schools of aesthetic education, 16 libraries.
Church of the Assumption (1756) and the gymnasium, built in the classical style in 1839, are among the oldest preserved buildings of Rivne. There are monuments of history and architecture of different historical epochs.
Rivne doesn’t have a lot of architectural sights, tourists are more interested in the Rivne Zoo. In the partly reconstructed city center there are several good hotels and restaurants, which makes Rivne an attractive stopping point.
The City Day of Rivne is celebrated on the last Sunday of August.
I hope that one day You will come and enjoy my city
Have a great day
Julia
PS. Waiting for your news for a curious Julia  ');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0xA9E1FF727DC94AF89165AEAA4DBEAB4F, '
My dear Julia, I guess you are still asleep now. But I want to say good morning, I hope you don’t think it’s too early. 
I went for a run in the morning and felt my heart was about to jump out of my mouth. It seemed that I hadn''t exercised for a long time. I think I need to exercise more, otherwise we will become beauty and the beast together.
I miss you, so I want to write to you, I hope you can see my greetings in the morning. It is still six letters before we can communicate freely. I look forward to it. This way I can share moon cakes and moon pictures with you.
Is cash still being used more in Ukraine? Mobile payment in China is very convenient now, you may not know, I have not used cash for a year, and there are only a few lonely credit cards in my poor wallet. You can even pay with your mobile phone by bus and taxi.
On September 14, a city in southern China was closed because stowaways entered there and brought the virus. I can''t understand, isn''t it a problem for the world to control the virus? Why spread it everywhere? This incident caused everyone in that city to do nucleic acid testing, which was terrible. Fortunately, China''s vaccine is about to go on the market. I think maybe the virus will be eliminated.
Yesterday, it started to snow in a city 300 kilometers away from my home. I think winter may come earlier this year. Maybe I should find out the winter clothes in advance.
Well, just write here, you have to cheer today.
Hugs
Jing');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0xAD201F8BBC3D4DEC819272C78E1DE8FE, '
Yes Jing,I have a great weekend because I am writing You my Sunday letter
Yes Jing, I guess that we have the same dissapointment in the opposite sex in our natuve countries that it is a really great decision to meet here at the international platform
My weekend is enough active. I walk, breath the fresh air, cook, clean, visit my parents and read the book Today I also need do some extra job tasks because it is an urgent task
Yes I try to learn English constantly, but it is not easy because You need work, take care on yourself, help for parents and a lot of another things. I am very buzy every day and it makes difficult to learn English intensively. 
We also have a cold weather here especially nights... It is nessecary to have somebody to hug and kiss during the cold night''s time.
This lonely Sunday What are you doing now, my Bear Jing? 
waiting for your news,
Julia');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0xAF69F482B5E84BA283EC744815D836CF, '
ello beautiful angel, Julia, first of all, how are you? How have you spent your days in quarantine? How have you been through this great problem in the world? It is very pleasant and clear that it makes me happy to see in your eyes, my possible future with a angel as beautiful and special as you.
I want you to know that my name is Rodrigo, I live in Playa del Carmen, Mexico. I am 38 years old and I am a divorced father, my daughter lives with her mother and I see her every 15 days that the law allows me.
I would also like to find true love again and I would love it to be you, because I am looking for a woman from abroad, well in my country it seems that I am not pleasant to them and I would like to try another type of woman with different culture, education and way of lifetime.
I have a question, do you really like me, I really am worthy of your beautiful beauty and do you want to know me better?
This portal charges to read your message I would like you to write me to my forgiveness email, but apparently this blocks the address, but I hope to see your prompt letter and get to know you better.
I hope you also have beautiful days and that you are very happy and free from suffering, I send you my best wishes and all my love, be happy ...
Rodrigo.');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0xB1A2A466F27B4B3580A90DE05EE0DAEA, '
Hola Julia
Encontré muy sinceras sus palabras y sus fotos son hermosas y muestran como es realmente.
Tengo una duda, ¿No le complica la diferencia de edad?
Me han escrito mucha mujer joven, y no les respondo ya que hasta pueden ser mis hijas.
Busco algo serio, me gusta ser responsable y al elegir una mujer joven corro el riego que pronto me deje.
Soy nuevo en este sitio, y me estoy adecuando a como funciona.
En todo caso, si no me resulta llegar a contactar a alguien, de igual forma tengo planeado viajar a Ucrania.
Saludos.');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0xB579304C951B43659C0774B851E5BAFE, ' Nick, DO YOU WANT TO KNOW ME BETTER? 

Yes it is... ');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0xBB7E803108FF4451B0FE51EC314CCD15, ' Witaj Julio nie wiem czy Dargomyśl by Ci odpowiada... ');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0xBC8B4D60EE384AC2A1CC8E1608648788, '
Ralf, ARE YOU SURE ABOUT THAT LADY? I like you and I will be waiting for your answer
Julia');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0xBF35421B6CCF43219BF61D88174770ED, '
Hi!How are you?
The page begins to charge money for speaking, I understand that it is your business, but if there really is no robot, or you are an employee working for this medium 
You know, how these websites work, and it is better to be sure who you are talking to.
Best regards!
A hug.');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0xC0C4D771D4DB4E459EFBDF7B16DBF9F5, ' Manuel, Yes it is a great chance to TRY this chanc... ');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0xC1581A19A1EA4692B6B462E3C63FE3EA, '
My dear Julia, like us, it is rainy here today, of course I am also sleepy.
I hope you have received my mail and I am waiting for your reply.
I think Ukraine has less food than China, because the Chinese eat chicken feet, pig feet, and animal offal. As for me, I like to eat trotters and lamb belly. Maybe I have a chance in the future and I can take you to taste it. I think you will love them too. Do you have any special ingredients?
Because the holiday is approaching, my work is very leisurely, so we will enter the holiday early. I can go home tomorrow afternoon and enjoy my 10-day holiday. I don''t have any plans yet, do you have any suggestions?
I know you are afraid of the cold, so I give you a warm hug on a rainy day
靖  ');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0xC24A221A1825427D8E5F1B7305D6B4ED, '
STOP HERE, Jing Ukrainian lonely candle needs YOUR FIRE
I have already come home and have taken the warm shower. Then I am going to have the light supper and have a fun time myself I am going to read the books, to listen the music and to drink the tasty green tea with my favorite candies tonight. Why are you so far from me?
We will be the lovely couple! I will try to be the most understanding, lovely, and gorgeous, and special one in your heart, a very special one.....
This is that story, my dream,  that hopefully will give you a big smile on your face.  We decide to cook together, as in me helping you, we go to the market, early in the morning, we buy what  ever we are going to be making this evening, I ask what should we get for dessert,  On your face was this sly grin, OH don''t worry about dessert, I am sure we can find something in the fridge for dessert. We stop at the wine store buy 2 bottles of Red wine and a bottle of Champaign. We get home you said, Ok let’s start making supper and lunch,  We were cutting away on the fruit, drinking the wine, In the back ground there was some soft music. So we both looked at each other with LOVE in our eyes, we started to dance real slow. It will be a perfect time together 
Your lonely Candle Julia. Would  you like to be my Fire?
');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0xC63595C4BEE54DFD9A2B0F567A291F7C, ' я хочу быть твоим щедрым
рогоносец муж.
Я никогд... ');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0xC874B623F1C3436EB4DCFC8FDAEEA5DC, '  :shock:  :shock:  :shock:  ');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0xCD7F42BBC93B4A129CBBBCB93DF3CD13, '
My dear Julia, I have applied for your personal contact information, but I haven''t received a reply yet.
I think you already know how to write my name in Chinese characters. Are you not curious about your name? Let me tell you, Julia=茱莉亚. Very beautiful words, right? Hope you like them.
Actually I am a lazy person, I don''t want to be rich, I just want to have a quiet life. But if I want to see you, I have to make changes. This is my motivation. My assessment has completed 6% this week. If it goes well, I will be eligible for futures investment and an account in five weeks. I have worked in the financial industry for 6-7 years, so I can be your personal financial advisor.
Very good, I think my personal guard can help me experience life in Ukraine better. I look forward to it.
I recently watched the news. Russia wants more Chinese men to marry Russian girls. There are good conditions, but they must stay in Russia to live, which has discouraged the enthusiasm of many Chinese men. do you know? China cannot have dual nationality, and in recent years, the government has not supported Chinese people to join other nationalities. For example, if some actors have joined other nationalities, the government will prohibit them from performing or endorsing in the country again. Does this happen in Ukraine?
do you know? Raising children in China is a huge expense. Although the state encourages people to have more children, young families cannot afford the cost of raising children and choose to have only one child. In China, people jokingly call children: four-legged gold swallowing beasts. Little animals that eat money, haha. How about Ukraine?
I made an appointment with my teammates to play football last night and I was very happy. After that, I went to the restaurant to eat with two teammates and drank three bottles of beer. I now control my drinking, not more than three bottles, which is not good for my health. What do you think of the three bottles? Does it need to be reduced? I listen to you, I need your true thoughts.
I look forward to our private exchanges. I can share more photos with you so that you can understand China more truly and the environment in which I live. Do you know the photos of the website? That was when I was as old as you. It was already 8 years ago. Do you think I should have a beard?
I wish you success in your work, and I wish you a happy weekend in advance.
Hugs
靖  ');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0xD45AED99D6C44E37880B22761006D8B3, '
My dear Miss Sun, Julia, first of all, please guess what song this is?
I wish this night to last forever
we could always be together
But by the dawn you ll be gone
once more I will be left all alone
Before you go my precious one
My only love, my brightest sun
I have one wish before you fly
Please come back tomorrow night
No one is more than you
Nothing compares to you
I am glad that the warm weather surrounds you. I know that good weather can improve people''s mood. Autumn is the harvest season, maybe we can also harvest some.
Yes, nothing in the world can stop two hearts wanting to be close to each other. Our hearts are a safe haven for each other. There is a poem in China that says: As long as the two loves stay the same until death, why bother to be greedy for my love and joy. I think this mood suits us well, because we may not be able to meet each other in a short time. Of course, maybe the Internet can help us.
do you know? I am used to a person falling asleep. Last summer, my daughter was scared at night and asked me to accompany her. But I can''t sleep all night, and I''m not used to the feeling of someone around me. Do you have such experience? Maybe loneliness should belong to me?
I am honored to be your gardener, watering you, taking you to the sun, sheltering you from wind and rain, and watching you become more beautiful. I think this will be a perfect experience.
It seems that Ukraine’s income is indeed lower than that of China. Do you know how much the ticket to Kiev is now? This requires connecting flights to two countries, about 85,000 hrn one-way, but before the epidemic, a round-trip ticket to Kiev only needed more than 30,000 hrn. I think maybe I need to find a way to make more money.I plan to move to my company to live, so that I can save some rent. At the same time, I took the trader exam. If it goes well, I can make money by investing in the futures market. Will you cheer me on?
I recently read some travel notes about Ukraine written by Chinese people, which gave me a better understanding of Ukraine. It seems that Ukrainians are not very friendly to Chinese. The airport staff will try to charge an extra fee to the person applying for the visa, which is about $60 per person. Taxis at the airport will also make guests pay more. But in the city, I think it is still very good, people are very enthusiastic and willing to help tourists. Is it really? Do you know these?
Yes, if you want to get the best treatment in China, you need to use imported medicines. This is very expensive, so the national medical insurance cannot be reimbursed. I can only choose to purchase another medical insurance from the insurance company. Last month, my mother fell and hurt her knee. It took about 10,000hrn to check up, and then the doctor said to go home and rest. It has been 50 days and she is much better now, so don''t worry.
Yes, I stayed at home with my little witch for more than two months. I felt very good at first, and I could spend time with her. But after more than a week, I became irritable. I had to help her do homework, play with her, cook her food, and coax her to sleep. It''s like this every day, it''s too hard. Fortunately, this time has passed.
I have applied to the website for your personal contact information, and I look forward to communicating with you freely so that we can share more details in life. I''m very excited. As for the language, it doesn''t matter. I can use Russian. Although there will be some minor flaws after translation, I don''t think it will affect the two hearts that yearn for each other, right?
I think viruses will be the theme of the whole world in the next few months, and I hope you all are well.
My Wednesday was rainy, but it has passed. My Thursday is sunny, but the temperature is already very low. I need to wear a jacket.
I hope my letter will bring you warmth, my Miss Sun.
靖');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0xD546ED593D2C4A14A7F17DCA8BD9BFA8, '
Hey Julia,
I really enjoyed hearing about our future time together.  I want it all and more.  It will be so nice.  Your letters always give me a smile.  Yes, I will be your fire.  We will burn together forever.I will always try to be the best man for you that I can be.  I will always help you, care for you and do my best to bring you happiness.  I''ll always do my best to help bring our dreams and goals for the future to fruition. 
Today is another hard day at work and I''m here for twelve hours today.  Later I will go  to the gym for the first time since the coronavirus.  Then home pays some bills and relax and watch a movie or read. I''m really waiting for the day when we can spend after work together.  And I can come home to your beautiful smiling face.  
Hope you have a nice day. I''m thinking of you.
Yours always
Dave');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0xDA081569F1F54220B04E9388E23FABB5, ' Bonjour Julia, j’ai beaucoup apprécié ta lettre, e... ');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0xDA854040D680453EAD7068B1AD339BDC, '
Hey Julia,  
Good morning my sweetheart Julia.  I did not change my furniture but now that you mention it I think I will at least move things around and change things up.
I would follow you to that place you speak of and never want to leave.  I want to look in your eyes and forget about the world and taste your sweet kiss.
If it''s a lonely evening with you then I''m all for it any time.  All I need is you to be entertained.
I prefer wine 
You make me laugh hehehe.  I do believe in magic.  Yes.
Yours always 
Dave');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0xDBF7E5C5BC0C49F6A0C2FCAF39EB7CA1, '
Hello my dear Julia:
You know I Will be very honest with you, young and pretty lady. First of all thank for your  letter, yes, San Isidro is really a very nice área to live, and secondly I am not atracted to young beautifull girls like  you. 
I''m serious in my search,  but I prefer ladies 40 y.o.
Or older. 
So I wish you good luck  in your search.
Send you a nice miss, take care Julia, sincerely Luis');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0xDFC66E39440744A49358BFEF499C6B60, '
My dear Julia, like us, it is rainy here today, of course I am also sleepy.
I hope you have received my mail and I am waiting for your reply.
I think Ukraine has less food than China, because the Chinese eat chicken feet, pig feet, and animal offal. As for me, I like to eat trotters and lamb belly. Maybe I have a chance in the future and I can take you to taste it. I think you will love them too. Do you have any special ingredients?
Because the holiday is approaching, my work is very leisurely, so we will enter the holiday early. I can go home tomorrow afternoon and enjoy my 10-day holiday. I don''t have any plans yet, do you have any suggestions?
I know you are afraid of the cold, so I give you a warm hug on a rainy day
靖  ');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0xE16E06EB4FD44CB9AB97FD7F5FD2F1B0, '
RALF, WHERE ARE YOU? Take a shower together in the morning? Agree? It is a perfect opportunity to start a day which is full of joy and satisfaction  Yes I am dreaming about our possible perfect future together…
It is really hard day because I want  to sleep sooo much! I couldn''t fall asleep during the long time yesterday and now I feel such as very tired girl after the night of hard working What about you?
ButI have the special plans for tonight. I want to dance with you. Would you like to dance with me? Dancing is an excellent form of exercise because it not only burns calories and builds muscles, but it also contributes to an overall sense of happiness. Dancing has an increased effect in this realm because it''s not only the physical activity, but also the music, that affect the mind. Do you have the favorite music for dancing with me? he he heI am very happy to know that we can communicate and soon we will meet. Thank you for coming into my life, and more importantly for staying with me regardless of my limitations. They said in Ukraine: “The mark of a real man, is a man who can allow himself to fall deeply in love with a woman”.  Do you agree with this statement? 
Your Future Lady,
Julia');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0xE1C963FF9F8E430AAAD604270C1EB35A, '
Good morning Julia,
I''ve thought a lot about you and I hope you are doing well.  I have to say that I really love your new pics.  You are the most beautiful woman to me.  On the inside and out.  I''d love to see you in that bussiness suit you speak of.
For work I just wear Jean''s and a t shirt.  Nothing special but that is because I do not work in a bussiness setting.  I work in more of a factory type place.  A large post office  building where mail is sorted.  I would like to wear a suit though.
As for Italian words all I know is Bella Serra (beautiful evening)  it''s a kind of wine.  Hehehe
Today I am getting my car fixed and am in a great mood.  I always think of you.  You are always in my heart and thoughts.
My two favorite things are coffee and chocolate.  I would like to try pumpkin porridge.  I''ve never had it but I''m sure I''d love it.
I miss you always my dear Julia
Yours always
Dave');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0xE3A33EFC0BEF47E095D4BA097B09F20C, '
I welcome you warmly. At the beginning I wanted to tell you that you are very beautiful. 
I would love to meet with you if you want. I would like to start a family ... 
But I must warn you ... I am very passionate haha Smile (I was not physically with a woman for a long time)do you want to check? Smile.Does not tolerate violence in a relationship. There should be love, passion and understanding in the relationship. 
People in a relationship should support each other and be with each other for good and bad.
I am 38 years old and I live in the beautiful city of Świdnica (voivodeship dolnyśląsk,next to the city of Wrocław) in Poland,
I like the animal, I spend my time actively ... I like good cinema and I also read a lot.
He often relaxes in the garden with music and a barbecue.
I also like traveling, small and big. 
I have been to the Czech Republic, Austria, Italy and Germany. Venice is not as beautiful as in the movies Smile)
The city where I live has 60,000 inhabitants and is very beautiful. 
There are a lot of greenery, parks, and there are a lot of forests aroundIf you want, check it on the internet Smile). 
Perhaps you will meet them personally.
I love children and I would like to have them my own ... maybe with you.
greetings and kisses. Marcin');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0xE5BA9AB28039483E87F6824EAC89D6B5, '
My dear Julia, I know what you mean. Autumn should be the harvest season, but we will feel lost if we have empty hands. But I think this autumn is a special season. Because we know each other. Hope this can change your mood.
My life is as monotonous as yours. This is the test of life for us. We must learn to find our own pleasure from some details. Now, you are the sunshine that illuminates my gray life, so I will bless you from afar until we meet. I don''t care much about the layout of the home. This may be the difference between men and women. I think most men don''t care about such details. But if my lover wants to change, I will actively participate in the design of new plans.
Yes, the virus is becoming serious, and we have no better way. We can only look forward to the launch of the vaccine. I heard that Chinese vaccines will be available as early as November. China is very good. There is almost no virus in the country. Almost 2,000 patients who have been diagnosed have entered China from abroad. China has strict border inspections, which has protected us very well. I think maybe China is one of the countries with the least virus in the world. I feel very lucky, because when the virus first broke out in China, everyone was very scared, but we controlled the spread of the virus very well. And everyone obeyed the government''s arrangements without any complaints. This is unimaginable in many other countries. What do you think?
It''s 10 o''clock in the evening, I am ready to go to bed, looking forward to you walking into my dream.
Also wish you a good dream in advance
靖  ');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0xE5DC1A612BB148768D3253A404231C4B, '
I welcome you warmly. At the beginning I wanted to tell you that you are very beautiful. 
I would love to meet with you if you want. I would like to start a family ... 
But I must warn you ... I am very passionate haha Smile (I was not physically with a woman for a long time)do you want to check? Smile.Does not tolerate violence in a relationship. There should be love, passion and understanding in the relationship. 
People in a relationship should support each other and be with each other for good and bad.
I am 38 years old and I live in the beautiful city of Świdnica (voivodeship dolnyśląsk,next to the city of Wrocław) in Poland,
I like the animal, I spend my time actively ... I like good cinema and I also read a lot.
He often relaxes in the garden with music and a barbecue.
I also like traveling, small and big. 
I have been to the Czech Republic, Austria, Italy and Germany. Venice is not as beautiful as in the movies Smile)
The city where I live has 60,000 inhabitants and is very beautiful. 
There are a lot of greenery, parks, and there are a lot of forests aroundIf you want, check it on the internet Smile). 
Perhaps you will meet them personally.
I love children and I would like to have them my own ... maybe with you.
greetings and kisses. Marcin');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0xE7CFA4EDC3D34C80B8A3B294C70BE308, '
Good  morning my Jing! Yes of course You can ask my private info at the agency. I will try to communicate with you privately without the help of translators. But I don''t use my private email every day,  I guess that every second day. We have the really warm and comfortable weather… There are a lot of sun rises  on  the ground and on the roofs of the houses. What a great mood I have! It would be funny to have the morning picnic with you in the park near my job. Such a little girl, I am dreaming about your  warm hugs and passionate kisses this  autumn  day. Autumn  is the time for love, for kisses and hugs Agree, Jing?
I am soo happy and  inside of me it is like a bright sunny day because I have you in my heart. My heart is full of love  Can I share it with you?  I want to pick you up and carry you to a romantic place where just the two of us know about.  This place is ours and only ours and no one else can ruin this place. We share thoughts, memories and lots of love is made in this special place. This place exists in our hearts and no one can take this away from us. Will we find such kind of place together? May be you have already found  that place for us, Jing?
Tell me about your  Wednesday routines
Your Ukrainian sun from the west of Ukraine,
Julia');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0xE9EF1C293B0A4236ACB51E179E410E1B, '
Hey Julia, I really enjoyed reading your letters.  You are amazing.  I will have time later after work to respond.  Talk to you then!
Dave');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0xEBAF38A726D6421B9190A5E8EEF3BC5D, '
Hey Julia
Your letter made me smile.  We are thinking the same.  I will explain later when I get home.  Then I''ll have more time to write.  Talk to you then.  Thanks for always thinking of me.  You are the best.
Dave');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0xED0E9A5A237F4B7AB0BAFEE0505923A4, ' working in a construktion comany in Ukraine then y... ');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0xEED0624EF9C34E6AB23BD13554614D1B, ' I am very glad to hear from you. Thank you for pay... ');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0xF0C008AEA7C143BAB9BCAD0088147821, '
Hello Julia, what an honor for me to meet you and to feel your interest in me. Also many thanks for your beautiful and UNDERLINE enchanting letter. I want to know you better. You are such a beautiful and very interesting woman for me. I would like to have a real meeting with you as soon as possible. I hope that _ does not scare you. If so it would be great if we could meet there because I think that you know someone better when you speak directly with him. Do you think the same? I hope to hear very soon from you. Greetings from Germany ');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0xF0F890CC1960483992F8FFA6BE3F8E17, '
My dear Julia,
Sorry for not replying sooner. I am really busy with work and forgot to read my email. All emails from this site are being delivered on a emailaddress I don''t reach much. That''s the reason I sent you e-mails from my primary email. 
Unfortunately you don''t read your email, I think also because its your secondary email? 
I do miss you and hope everything is okay. 
How is everything going at work? Do you have a lot of trouble with work because of COVID-19?
Hope to hear from you soon. 
Your guy,
Alex');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0xF26B4B74D6064B938F827E9FAB0B6D52, ' Me has encantado me gusto mucho ver tus fotografía... ');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0xF3F7E843D4834118B3F3F5491EF30699, '
Jing, "The strongest love is the one that is not afraid to show weakness." I read the novel Paulo Coelho  last weekend and I was impressed by these words. Agree, Jing?  
But the life is continue it’s a  circle… We can’t stop, we live day by day… This stupid virus is going to come back  with the bigger force than in spring time I guess that soon we will have a strict quarantine again I am afraid of this period… It will be perfect to spend this exciting period at your strong and warm hugs But You are far from me I got up very early again. A little description of my morning… At first, the morning exercises, then the contrasting shower after that the light breakfast (buckwheat with milk), then the quick road by bus… We have the really sunny and warm  morning such as not typical autumn weather. I can wear the summer light red dress ... There is a lot of sun in Ukraine Could you imagine how I look right now?
What  kind  of work do you like best of all? Do you prefer creative work or work with peoples or may be with documents or just with technical side such as computers, Jing?  I like the creative work,  the work with people.
Yes Jing, I noticed that You have an English name, but I thought that may be I don''t know any rules of the foreign languages
My name is Julia My mum wanted that her daughter had such kind of name) Sorry, but I don''t have any special story)
Yes our borders are closed now, because of virus reason. It is not contradictory, but it is a sad statistics,  I guess. 
The statistics is middle of new cases if we compare the situation in Ukraine at all.
Tell me about your plans for this autumn cold evening
Yours, 
Julia
PS. I will try to write you also this evening, because I also miss you during that buzy days.');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0xF622985E4A0145FA9A5ED7CF24DCE6EE, '
My dear Julia,
I miss you too. I wish you were here right now and I could hold in my arms. 
I rather email you with my private email, but if you have trouble with your email it would be hard. You should let someone from IT check your email problems. I can check it out, but I have to say my fee is a bit high (100 kisses?).  
Here in Holland we also have more cases and more and more businesses struggle with it. We had to set harder rules for restaurants and clubs. Most problems exist in the big cities (Rotterdam, Amsterdam). 
I wish you were here. 
I really need your love and support. 
With love, 
Alex');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0xFB2B08258A5D42F9B4EF8155AE07EB5A, ' Привет, Джули! Спасибо за красивое письмо. Вы крас... ');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0xFC1A106AF69E48CBBADD02C2F0E7BE6C, '
Hey Julia,
Glad to hear that you are happy and having a great day.  Your letter made me smile.  Thank you for always being there for me.  You are in my heart too. I want very much to go to that special place with you.  If we were with eachother now I would show you what you mean to me. 
I''m in a great mood too because I have you. Each day we get closer to the day when we are together in person.  Today is my day off and I went to the gym, then visited friends and now I''m just relaxing and preparing dinner.  
I''d like for us to be close and always become closer  Mentally, physically, spiritually.  Hope my letter warms your heart like yours did mine.
Yours always
Dave  ');
INSERT INTO nataly_schema.Texts (text_id, text) VALUES (0xFCEF7F6A3D4B4A449B698998A4195D37, '
Hi!How are you?
The page begins to charge money for speaking, I understand that it is your business, but if there really is no robot, or you are an employee working for this medium, write me at whatsapp  
You know, how these websites work, and it is better to be sure who you are talking to.
Best regards!
A hug.');