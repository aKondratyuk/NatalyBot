create table Religions
(
    religion varchar(190) not null
        primary key
);

INSERT INTO nataly_schema.Religions (religion) VALUES ('Adventist');
INSERT INTO nataly_schema.Religions (religion) VALUES ('Agnostic');
INSERT INTO nataly_schema.Religions (religion) VALUES ('Atheist');
INSERT INTO nataly_schema.Religions (religion) VALUES ('Baptist');
INSERT INTO nataly_schema.Religions (religion) VALUES ('Buddhist');
INSERT INTO nataly_schema.Religions (religion) VALUES ('Caodaism');
INSERT INTO nataly_schema.Religions (religion) VALUES ('Catholic');
INSERT INTO nataly_schema.Religions (religion) VALUES ('Christian');
INSERT INTO nataly_schema.Religions (religion) VALUES ('Hindu');
INSERT INTO nataly_schema.Religions (religion) VALUES ('I prefer not to say');
INSERT INTO nataly_schema.Religions (religion) VALUES ('Iskcon');
INSERT INTO nataly_schema.Religions (religion) VALUES ('Jainism');
INSERT INTO nataly_schema.Religions (religion) VALUES ('Jewish');
INSERT INTO nataly_schema.Religions (religion) VALUES ('Methodist');
INSERT INTO nataly_schema.Religions (religion) VALUES ('Mormon');
INSERT INTO nataly_schema.Religions (religion) VALUES ('Moslem');
INSERT INTO nataly_schema.Religions (religion) VALUES ('Orthodox');
INSERT INTO nataly_schema.Religions (religion) VALUES ('Other');
INSERT INTO nataly_schema.Religions (religion) VALUES ('Pentecostal');
INSERT INTO nataly_schema.Religions (religion) VALUES ('Protestant');
INSERT INTO nataly_schema.Religions (religion) VALUES ('Quaker');
INSERT INTO nataly_schema.Religions (religion) VALUES ('Scientology');
INSERT INTO nataly_schema.Religions (religion) VALUES ('Shinto');
INSERT INTO nataly_schema.Religions (religion) VALUES ('Sikhism');
INSERT INTO nataly_schema.Religions (religion) VALUES ('Spiritual');
INSERT INTO nataly_schema.Religions (religion) VALUES ('Taoism');
INSERT INTO nataly_schema.Religions (religion) VALUES ('Wiccan');
INSERT INTO nataly_schema.Religions (religion) VALUES ('Zoroastrian');