create table Invites
(
    invite_id   binary(16)                          not null
        primary key,
    create_time timestamp default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP
)
    charset = utf8;

INSERT INTO nataly_schema.Invites (invite_id, create_time) VALUES (0x3936F24B40DF46408F31AE0F8B4EE92F, '2020-10-13 11:10:25');
INSERT INTO nataly_schema.Invites (invite_id, create_time) VALUES (0x3F019B59F3AD47CEB82A26FA8BAE4C32, '2020-10-11 13:23:09');
INSERT INTO nataly_schema.Invites (invite_id, create_time) VALUES (0x5122FB9B500146EEA67DFD5C7735A1E7, '2020-11-17 17:03:32');
INSERT INTO nataly_schema.Invites (invite_id, create_time) VALUES (0x548BBF757F014A68AEFEF3B72A155962, '2020-11-17 15:31:28');
INSERT INTO nataly_schema.Invites (invite_id, create_time) VALUES (0x7A30AF30691645B8AA065DDA581A674D, '2020-10-05 18:02:39');
INSERT INTO nataly_schema.Invites (invite_id, create_time) VALUES (0x83D7B0ECE4F743978C79147C43D3AD7C, '2020-10-07 22:54:24');
INSERT INTO nataly_schema.Invites (invite_id, create_time) VALUES (0x85E7AB081C0D46CAAC4E92BE9BDB05E7, '2020-11-17 15:29:21');
INSERT INTO nataly_schema.Invites (invite_id, create_time) VALUES (0x898F746A70B141D6BD920E7F386143D1, '2020-11-20 13:47:52');
INSERT INTO nataly_schema.Invites (invite_id, create_time) VALUES (0x9A32A3E1375B4BF9851CF45587A28354, '2020-11-17 15:30:26');
INSERT INTO nataly_schema.Invites (invite_id, create_time) VALUES (0x9A3E9A31DED94D13A2EE0C19B23E57E3, '2020-10-07 22:54:20');
INSERT INTO nataly_schema.Invites (invite_id, create_time) VALUES (0xA9ABCDBEBCFF422E91964748FF9F1E75, '2020-11-17 16:54:20');
INSERT INTO nataly_schema.Invites (invite_id, create_time) VALUES (0xBE569A49D02348F8AB1FC1F503B2B157, '2020-10-07 13:15:50');
INSERT INTO nataly_schema.Invites (invite_id, create_time) VALUES (0xD5F337D29D454FB89BE9CDDA5AD8CDDF, '2020-11-17 17:23:11');
INSERT INTO nataly_schema.Invites (invite_id, create_time) VALUES (0xE3AFCB520090474090DABE690ECEE909, '2020-10-11 18:07:05');
INSERT INTO nataly_schema.Invites (invite_id, create_time) VALUES (0xE6D78DF97E2F4C278B3730277282E463, '2020-10-07 13:15:40');
INSERT INTO nataly_schema.Invites (invite_id, create_time) VALUES (0xEAB7244C68D24129A178C193FC1AA92B, '2020-11-17 15:47:32');