create table Visibility
(
    profile_id varchar(20)  not null,
    login      varchar(190) not null,
    primary key (profile_id, login),
    constraint FK_VISIBILI_VISIBILIT_PROFILES
        foreign key (profile_id) references Profiles (profile_id),
    constraint FK_VISIBILI_VISIBILIT_USERS
        foreign key (login) references Users (login)
);

INSERT INTO nataly_schema.Visibility (profile_id, login) VALUES ('1001355233', '145@gmail.com');
INSERT INTO nataly_schema.Visibility (profile_id, login) VALUES ('1001485714', '145@gmail.com');
INSERT INTO nataly_schema.Visibility (profile_id, login) VALUES ('1000868043', 'admin3@gmail.com');
INSERT INTO nataly_schema.Visibility (profile_id, login) VALUES ('1001355233', 'admin3@gmail.com');
INSERT INTO nataly_schema.Visibility (profile_id, login) VALUES ('1001485714', 'admin3@gmail.com');
INSERT INTO nataly_schema.Visibility (profile_id, login) VALUES ('1000514482', 'admin@gmail.com');
INSERT INTO nataly_schema.Visibility (profile_id, login) VALUES ('1000868043', 'admin@gmail.com');
INSERT INTO nataly_schema.Visibility (profile_id, login) VALUES ('1001355233', 'admin@gmail.com');
INSERT INTO nataly_schema.Visibility (profile_id, login) VALUES ('1001485714', 'admin@gmail.com');
INSERT INTO nataly_schema.Visibility (profile_id, login) VALUES ('1001573218', 'admin@gmail.com');
INSERT INTO nataly_schema.Visibility (profile_id, login) VALUES ('1001600532', 'admin@gmail.com');
INSERT INTO nataly_schema.Visibility (profile_id, login) VALUES ('1001651264', 'admin@gmail.com');
INSERT INTO nataly_schema.Visibility (profile_id, login) VALUES ('1001716782', 'admin@gmail.com');
INSERT INTO nataly_schema.Visibility (profile_id, login) VALUES ('1001573218', 'illya123456@live.ru');
INSERT INTO nataly_schema.Visibility (profile_id, login) VALUES ('1000868043', 'julia777happy@ukr.net');
INSERT INTO nataly_schema.Visibility (profile_id, login) VALUES ('1001355233', 'julia777happy@ukr.net');
INSERT INTO nataly_schema.Visibility (profile_id, login) VALUES ('1001485714', 'julia777happy@ukr.net');
INSERT INTO nataly_schema.Visibility (profile_id, login) VALUES ('1001573218', 'julia777happy@ukr.net');