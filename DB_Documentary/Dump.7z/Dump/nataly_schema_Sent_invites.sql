create table Sent_invites
(
    invite_id binary(16)   not null,
    login     varchar(190) not null,
    primary key (invite_id, login),
    constraint FK_SENT_I_INVITE_HA_INVITES
        foreign key (invite_id) references Invites (invite_id),
    constraint FK_SENT_I_USER_HAS__USERS
        foreign key (login) references Users (login)
);

INSERT INTO nataly_schema.Sent_invites (invite_id, login) VALUES (0x83D7B0ECE4F743978C79147C43D3AD7C, '145@gmail.com');
INSERT INTO nataly_schema.Sent_invites (invite_id, login) VALUES (0xBE569A49D02348F8AB1FC1F503B2B157, '375@gmail.com');
INSERT INTO nataly_schema.Sent_invites (invite_id, login) VALUES (0x9A3E9A31DED94D13A2EE0C19B23E57E3, '793@gmail.com');
INSERT INTO nataly_schema.Sent_invites (invite_id, login) VALUES (0xE6D78DF97E2F4C278B3730277282E463, '795@gmail.com');
INSERT INTO nataly_schema.Sent_invites (invite_id, login) VALUES (0x15AFE4472CEC4D9EAA9FA9CBF9AA3BE0, 'admin@gmail.com');
INSERT INTO nataly_schema.Sent_invites (invite_id, login) VALUES (0x1B58F36CD07845DFB485F9092F26D3FD, 'admin@gmail.com');
INSERT INTO nataly_schema.Sent_invites (invite_id, login) VALUES (0x3936F24B40DF46408F31AE0F8B4EE92F, 'admin@gmail.com');
INSERT INTO nataly_schema.Sent_invites (invite_id, login) VALUES (0x3F019B59F3AD47CEB82A26FA8BAE4C32, 'admin@gmail.com');
INSERT INTO nataly_schema.Sent_invites (invite_id, login) VALUES (0x7A30AF30691645B8AA065DDA581A674D, 'admin@gmail.com');
INSERT INTO nataly_schema.Sent_invites (invite_id, login) VALUES (0x83D7B0ECE4F743978C79147C43D3AD7C, 'admin@gmail.com');
INSERT INTO nataly_schema.Sent_invites (invite_id, login) VALUES (0x9A3E9A31DED94D13A2EE0C19B23E57E3, 'admin@gmail.com');
INSERT INTO nataly_schema.Sent_invites (invite_id, login) VALUES (0xBE569A49D02348F8AB1FC1F503B2B157, 'admin@gmail.com');
INSERT INTO nataly_schema.Sent_invites (invite_id, login) VALUES (0xE3AFCB520090474090DABE690ECEE909, 'admin@gmail.com');
INSERT INTO nataly_schema.Sent_invites (invite_id, login) VALUES (0xE6D78DF97E2F4C278B3730277282E463, 'admin@gmail.com');
INSERT INTO nataly_schema.Sent_invites (invite_id, login) VALUES (0x3F019B59F3AD47CEB82A26FA8BAE4C32, 'illya123456@live.ru');
INSERT INTO nataly_schema.Sent_invites (invite_id, login) VALUES (0xE3AFCB520090474090DABE690ECEE909, 'illya123456@outlook.com');
INSERT INTO nataly_schema.Sent_invites (invite_id, login) VALUES (0x1B58F36CD07845DFB485F9092F26D3FD, 'julia777happy@ukr.net');
INSERT INTO nataly_schema.Sent_invites (invite_id, login) VALUES (0x15AFE4472CEC4D9EAA9FA9CBF9AA3BE0, 'plug2up@gmail.com');
INSERT INTO nataly_schema.Sent_invites (invite_id, login) VALUES (0x3936F24B40DF46408F31AE0F8B4EE92F, 'r.buhtiyarov@gmail.com');
INSERT INTO nataly_schema.Sent_invites (invite_id, login) VALUES (0x7A30AF30691645B8AA065DDA581A674D, 'test_invite@gmail.com');