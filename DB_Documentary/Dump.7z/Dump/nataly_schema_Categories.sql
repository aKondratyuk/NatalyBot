create table Categories
(
    category_name varchar(190) not null
        primary key
);

INSERT INTO nataly_schema.Categories (category_name) VALUES ('body_type');
INSERT INTO nataly_schema.Categories (category_name) VALUES ('children');
INSERT INTO nataly_schema.Categories (category_name) VALUES ('drinker');
INSERT INTO nataly_schema.Categories (category_name) VALUES ('education');
INSERT INTO nataly_schema.Categories (category_name) VALUES ('height');
INSERT INTO nataly_schema.Categories (category_name) VALUES ('income');
INSERT INTO nataly_schema.Categories (category_name) VALUES ('looking_for_a_body_type');
INSERT INTO nataly_schema.Categories (category_name) VALUES ('looking_for_a_height');
INSERT INTO nataly_schema.Categories (category_name) VALUES ('martial_status');
INSERT INTO nataly_schema.Categories (category_name) VALUES ('relationship');
INSERT INTO nataly_schema.Categories (category_name) VALUES ('smoker');
INSERT INTO nataly_schema.Categories (category_name) VALUES ('want_children');
INSERT INTO nataly_schema.Categories (category_name) VALUES ('where_children');