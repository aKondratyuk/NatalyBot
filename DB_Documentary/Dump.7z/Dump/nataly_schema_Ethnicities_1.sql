create table Ethnicities
(
    ethnicity_name varchar(190) not null
        primary key
)
    charset = utf8;

INSERT INTO nataly_schema.Ethnicities (ethnicity_name) VALUES ('African');
INSERT INTO nataly_schema.Ethnicities (ethnicity_name) VALUES ('African American');
INSERT INTO nataly_schema.Ethnicities (ethnicity_name) VALUES ('Asian');
INSERT INTO nataly_schema.Ethnicities (ethnicity_name) VALUES ('Caucasian');
INSERT INTO nataly_schema.Ethnicities (ethnicity_name) VALUES ('East Indian');
INSERT INTO nataly_schema.Ethnicities (ethnicity_name) VALUES ('Hispanic');
INSERT INTO nataly_schema.Ethnicities (ethnicity_name) VALUES ('I prefer not to say');
INSERT INTO nataly_schema.Ethnicities (ethnicity_name) VALUES ('Indian');
INSERT INTO nataly_schema.Ethnicities (ethnicity_name) VALUES ('Latino');
INSERT INTO nataly_schema.Ethnicities (ethnicity_name) VALUES ('Mediterranean');
INSERT INTO nataly_schema.Ethnicities (ethnicity_name) VALUES ('Middle Eastern');
INSERT INTO nataly_schema.Ethnicities (ethnicity_name) VALUES ('Mixed');