create table Roles_of_users
(
    login     varchar(190) not null,
    user_role varchar(190) not null,
    primary key (login, user_role),
    constraint FK_ROLES_OF_ROLE_ASSI_USER_ROL
        foreign key (user_role) references User_roles (user_role),
    constraint FK_ROLES_OF_USER_HAS__USERS
        foreign key (login) references Users (login)
);

INSERT INTO nataly_schema.Roles_of_users (login, user_role) VALUES ('admin2@gmail.com', 'admin');
INSERT INTO nataly_schema.Roles_of_users (login, user_role) VALUES ('admin3@gmail.com', 'admin');
INSERT INTO nataly_schema.Roles_of_users (login, user_role) VALUES ('admin@gmail.com', 'admin');
INSERT INTO nataly_schema.Roles_of_users (login, user_role) VALUES ('145@gmail.com', 'default');
INSERT INTO nataly_schema.Roles_of_users (login, user_role) VALUES ('375@gmail.com', 'default');
INSERT INTO nataly_schema.Roles_of_users (login, user_role) VALUES ('793@gmail.com', 'default');
INSERT INTO nataly_schema.Roles_of_users (login, user_role) VALUES ('795@gmail.com', 'default');
INSERT INTO nataly_schema.Roles_of_users (login, user_role) VALUES ('illya123456@live.ru', 'default');
INSERT INTO nataly_schema.Roles_of_users (login, user_role) VALUES ('illya123456@outlook.com', 'default');
INSERT INTO nataly_schema.Roles_of_users (login, user_role) VALUES ('julia777happy@ukr.net', 'default');
INSERT INTO nataly_schema.Roles_of_users (login, user_role) VALUES ('plug2up@gmail.com', 'default');
INSERT INTO nataly_schema.Roles_of_users (login, user_role) VALUES ('r.buhtiyarov@gmail.com', 'default');
INSERT INTO nataly_schema.Roles_of_users (login, user_role) VALUES ('test_invite@gmail.com', 'default');
INSERT INTO nataly_schema.Roles_of_users (login, user_role) VALUES ('111@gmail.com', 'deleted');
INSERT INTO nataly_schema.Roles_of_users (login, user_role) VALUES ('124@gmail.com', 'deleted');
INSERT INTO nataly_schema.Roles_of_users (login, user_role) VALUES ('335@gmail.com', 'deleted');
INSERT INTO nataly_schema.Roles_of_users (login, user_role) VALUES ('786@gmail.com', 'deleted');
INSERT INTO nataly_schema.Roles_of_users (login, user_role) VALUES ('842@gmail.com', 'deleted');
INSERT INTO nataly_schema.Roles_of_users (login, user_role) VALUES ('l124@gmail.com', 'deleted');