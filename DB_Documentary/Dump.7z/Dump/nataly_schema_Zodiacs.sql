create table Zodiacs
(
    zodiac varchar(190) not null
        primary key
);

INSERT INTO nataly_schema.Zodiacs (zodiac) VALUES ('Aquarius');
INSERT INTO nataly_schema.Zodiacs (zodiac) VALUES ('Aries');
INSERT INTO nataly_schema.Zodiacs (zodiac) VALUES ('Cancer');
INSERT INTO nataly_schema.Zodiacs (zodiac) VALUES ('Capricorn');
INSERT INTO nataly_schema.Zodiacs (zodiac) VALUES ('Gemini');
INSERT INTO nataly_schema.Zodiacs (zodiac) VALUES ('Leo');
INSERT INTO nataly_schema.Zodiacs (zodiac) VALUES ('Libra');
INSERT INTO nataly_schema.Zodiacs (zodiac) VALUES ('Pisces');
INSERT INTO nataly_schema.Zodiacs (zodiac) VALUES ('Sagittarius');
INSERT INTO nataly_schema.Zodiacs (zodiac) VALUES ('Scorpio');
INSERT INTO nataly_schema.Zodiacs (zodiac) VALUES ('Taurus');
INSERT INTO nataly_schema.Zodiacs (zodiac) VALUES ('Virgo');