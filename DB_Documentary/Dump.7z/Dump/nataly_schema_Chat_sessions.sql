create table Chat_sessions
(
    chat_id    binary(16)  not null,
    profile_id varchar(20) not null,
    primary key (chat_id, profile_id),
    constraint FK_CHAT_SES_CHAT_IN_S_CHATS
        foreign key (chat_id) references Chats (chat_id),
    constraint FK_CHAT_SES_PROFILE_I_PROFILES
        foreign key (profile_id) references Profiles (profile_id)
);

INSERT INTO nataly_schema.Chat_sessions (chat_id, profile_id) VALUES (0xBC0762E44B324F1695FDC51AFA151C69, '1000514482');
INSERT INTO nataly_schema.Chat_sessions (chat_id, profile_id) VALUES (0x17A221EEB9DF46F69B911E5C96C45068, '1000868043');
INSERT INTO nataly_schema.Chat_sessions (chat_id, profile_id) VALUES (0x2DDF7A0D3FEE41BFB2CEA0FB6854D76A, '1000868043');
INSERT INTO nataly_schema.Chat_sessions (chat_id, profile_id) VALUES (0x3D4D75937416495F99BD378CE7C76BE5, '1000868043');
INSERT INTO nataly_schema.Chat_sessions (chat_id, profile_id) VALUES (0x4F08DD2A3B4B4D6383F808697008BE5B, '1000868043');
INSERT INTO nataly_schema.Chat_sessions (chat_id, profile_id) VALUES (0x9DF6B219861F4B369A3292EFF9385119, '1000868043');
INSERT INTO nataly_schema.Chat_sessions (chat_id, profile_id) VALUES (0xBC0762E44B324F1695FDC51AFA151C69, '1000868043');
INSERT INTO nataly_schema.Chat_sessions (chat_id, profile_id) VALUES (0x3D4D75937416495F99BD378CE7C76BE5, '1001355233');
INSERT INTO nataly_schema.Chat_sessions (chat_id, profile_id) VALUES (0x2DDF7A0D3FEE41BFB2CEA0FB6854D76A, '1001485714');
INSERT INTO nataly_schema.Chat_sessions (chat_id, profile_id) VALUES (0x9DF6B219861F4B369A3292EFF9385119, '1001573218');
INSERT INTO nataly_schema.Chat_sessions (chat_id, profile_id) VALUES (0x4F08DD2A3B4B4D6383F808697008BE5B, '1001600532');
INSERT INTO nataly_schema.Chat_sessions (chat_id, profile_id) VALUES (0x17A221EEB9DF46F69B911E5C96C45068, '1001716782');