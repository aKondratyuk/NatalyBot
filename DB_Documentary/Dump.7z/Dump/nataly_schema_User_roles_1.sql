create table User_roles
(
    user_role varchar(190) not null
        primary key
)
    charset = utf8;

INSERT INTO nataly_schema.User_roles (user_role) VALUES ('admin');
INSERT INTO nataly_schema.User_roles (user_role) VALUES ('default');
INSERT INTO nataly_schema.User_roles (user_role) VALUES ('deleted');
INSERT INTO nataly_schema.User_roles (user_role) VALUES ('moderator');