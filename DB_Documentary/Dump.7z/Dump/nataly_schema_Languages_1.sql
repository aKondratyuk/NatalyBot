create table Languages
(
    language varchar(190) not null
        primary key
)
    charset = utf8;

INSERT INTO nataly_schema.Languages (language) VALUES ('');
INSERT INTO nataly_schema.Languages (language) VALUES ('---');
INSERT INTO nataly_schema.Languages (language) VALUES ('Afrikaans');
INSERT INTO nataly_schema.Languages (language) VALUES ('Arabic');
INSERT INTO nataly_schema.Languages (language) VALUES ('Belorussian');
INSERT INTO nataly_schema.Languages (language) VALUES ('Bulgarian');
INSERT INTO nataly_schema.Languages (language) VALUES ('Burmese');
INSERT INTO nataly_schema.Languages (language) VALUES ('Cantonese');
INSERT INTO nataly_schema.Languages (language) VALUES ('Croatian');
INSERT INTO nataly_schema.Languages (language) VALUES ('Czech');
INSERT INTO nataly_schema.Languages (language) VALUES ('Danish');
INSERT INTO nataly_schema.Languages (language) VALUES ('Dutch');
INSERT INTO nataly_schema.Languages (language) VALUES ('English');
INSERT INTO nataly_schema.Languages (language) VALUES ('Esperanto');
INSERT INTO nataly_schema.Languages (language) VALUES ('Estonian');
INSERT INTO nataly_schema.Languages (language) VALUES ('Finnish');
INSERT INTO nataly_schema.Languages (language) VALUES ('French');
INSERT INTO nataly_schema.Languages (language) VALUES ('German');
INSERT INTO nataly_schema.Languages (language) VALUES ('Greek');
INSERT INTO nataly_schema.Languages (language) VALUES ('Gujrati');
INSERT INTO nataly_schema.Languages (language) VALUES ('Hebrew');
INSERT INTO nataly_schema.Languages (language) VALUES ('Hindi');
INSERT INTO nataly_schema.Languages (language) VALUES ('Hungarian');
INSERT INTO nataly_schema.Languages (language) VALUES ('Icelandic');
INSERT INTO nataly_schema.Languages (language) VALUES ('Indian');
INSERT INTO nataly_schema.Languages (language) VALUES ('Indonesian');
INSERT INTO nataly_schema.Languages (language) VALUES ('Italian');
INSERT INTO nataly_schema.Languages (language) VALUES ('Japanese');
INSERT INTO nataly_schema.Languages (language) VALUES ('Korean');
INSERT INTO nataly_schema.Languages (language) VALUES ('Latvian');
INSERT INTO nataly_schema.Languages (language) VALUES ('Lithuanian');
INSERT INTO nataly_schema.Languages (language) VALUES ('Malay');
INSERT INTO nataly_schema.Languages (language) VALUES ('Mandarin');
INSERT INTO nataly_schema.Languages (language) VALUES ('Marathi');
INSERT INTO nataly_schema.Languages (language) VALUES ('Moldovian');
INSERT INTO nataly_schema.Languages (language) VALUES ('Nepalese');
INSERT INTO nataly_schema.Languages (language) VALUES ('Norwegian');
INSERT INTO nataly_schema.Languages (language) VALUES ('Not specified');
INSERT INTO nataly_schema.Languages (language) VALUES ('Persian');
INSERT INTO nataly_schema.Languages (language) VALUES ('Polish');
INSERT INTO nataly_schema.Languages (language) VALUES ('Portuguese');
INSERT INTO nataly_schema.Languages (language) VALUES ('Punjabi');
INSERT INTO nataly_schema.Languages (language) VALUES ('Romanian');
INSERT INTO nataly_schema.Languages (language) VALUES ('Russian');
INSERT INTO nataly_schema.Languages (language) VALUES ('Serbian');
INSERT INTO nataly_schema.Languages (language) VALUES ('Spanish');
INSERT INTO nataly_schema.Languages (language) VALUES ('Swedish');
INSERT INTO nataly_schema.Languages (language) VALUES ('Tagalog');
INSERT INTO nataly_schema.Languages (language) VALUES ('Taiwanese');
INSERT INTO nataly_schema.Languages (language) VALUES ('Tamil');
INSERT INTO nataly_schema.Languages (language) VALUES ('Telugu');
INSERT INTO nataly_schema.Languages (language) VALUES ('Thai');
INSERT INTO nataly_schema.Languages (language) VALUES ('Tongan');
INSERT INTO nataly_schema.Languages (language) VALUES ('Turkish');
INSERT INTO nataly_schema.Languages (language) VALUES ('Ukrainian');
INSERT INTO nataly_schema.Languages (language) VALUES ('Urdu');
INSERT INTO nataly_schema.Languages (language) VALUES ('Vietnamese');
INSERT INTO nataly_schema.Languages (language) VALUES ('Visayan');