create table Profiles
(
    profile_id       varchar(20)          not null
        primary key,
    profile_password varchar(190)         null,
    available        tinyint(1) default 1 null,
    can_receive      tinyint(1) default 1 null,
    msg_limit        int                  null,
    profile_type     varchar(190)         null
);

INSERT INTO nataly_schema.Profiles (profile_id, profile_password, available, can_receive, msg_limit, profile_type) VALUES ('1000514482', null, 0, 1, null, null);
INSERT INTO nataly_schema.Profiles (profile_id, profile_password, available, can_receive, msg_limit, profile_type) VALUES ('1000868043', 'SWEETY777', 1, 1, null, null);
INSERT INTO nataly_schema.Profiles (profile_id, profile_password, available, can_receive, msg_limit, profile_type) VALUES ('1001355233', null, 1, 1, null, null);
INSERT INTO nataly_schema.Profiles (profile_id, profile_password, available, can_receive, msg_limit, profile_type) VALUES ('1001485714', null, 1, 1, null, null);
INSERT INTO nataly_schema.Profiles (profile_id, profile_password, available, can_receive, msg_limit, profile_type) VALUES ('1001573218', null, 1, 1, null, null);
INSERT INTO nataly_schema.Profiles (profile_id, profile_password, available, can_receive, msg_limit, profile_type) VALUES ('1001600532', null, 1, 1, null, null);
INSERT INTO nataly_schema.Profiles (profile_id, profile_password, available, can_receive, msg_limit, profile_type) VALUES ('1001650728', 'SWEETY777', 1, 1, null, null);
INSERT INTO nataly_schema.Profiles (profile_id, profile_password, available, can_receive, msg_limit, profile_type) VALUES ('1001651264', '111nat', 1, 1, null, null);
INSERT INTO nataly_schema.Profiles (profile_id, profile_password, available, can_receive, msg_limit, profile_type) VALUES ('1001663985', 'lenor777', 1, 1, null, null);
INSERT INTO nataly_schema.Profiles (profile_id, profile_password, available, can_receive, msg_limit, profile_type) VALUES ('1001668497', 'SWEETY777', 1, 1, null, null);
INSERT INTO nataly_schema.Profiles (profile_id, profile_password, available, can_receive, msg_limit, profile_type) VALUES ('1001716782', null, 0, 1, null, null);
INSERT INTO nataly_schema.Profiles (profile_id, profile_password, available, can_receive, msg_limit, profile_type) VALUES ('admin@gmail.com', 'adminadmin', 1, 1, null, null);