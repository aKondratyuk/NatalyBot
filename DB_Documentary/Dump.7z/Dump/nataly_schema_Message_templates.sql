create table Message_templates
(
    profile_id  varchar(20) default '' not null,
    text_id     binary(16)  default                  not null,
    text_number int         default 1  null,
    primary key (profile_id, text_id),
    constraint Message_templates_Profiles_profile_id_fk
        foreign key (profile_id) references Profiles (profile_id),
    constraint Message_templates_Texts_text_id_fk
        foreign key (text_id) references Texts (text_id)
)
    charset = utf8;

INSERT INTO nataly_schema.Message_templates (profile_id, text_id, text_number) VALUES ('1000868043', 0x08E7F696AEEA4280908CF22A70726835, 3);
INSERT INTO nataly_schema.Message_templates (profile_id, text_id, text_number) VALUES ('1000868043', 0x42294048C3E24D4788364F5148124D51, 5);
INSERT INTO nataly_schema.Message_templates (profile_id, text_id, text_number) VALUES ('1000868043', 0x73E155CCC24A41EB975CDD7654EBECA6, 2);
INSERT INTO nataly_schema.Message_templates (profile_id, text_id, text_number) VALUES ('1000868043', 0x9924B1D7A91B4E18A0F0730C9FCDF627, 4);
INSERT INTO nataly_schema.Message_templates (profile_id, text_id, text_number) VALUES ('1000868043', 0xFB3D47310D564CCAB9310630895E2B6F, 1);
INSERT INTO nataly_schema.Message_templates (profile_id, text_id, text_number) VALUES ('1001636771', 0x285BDB97FEFD42CE8F2AB3474A4D74C6, 5);
INSERT INTO nataly_schema.Message_templates (profile_id, text_id, text_number) VALUES ('1001636771', 0x7CE85119794F41AF9DEEE0AFA32794DA, 1);
INSERT INTO nataly_schema.Message_templates (profile_id, text_id, text_number) VALUES ('1001636771', 0xCC05970DA9A6466C9E41AA72EAD648F9, 2);
INSERT INTO nataly_schema.Message_templates (profile_id, text_id, text_number) VALUES ('1001636771', 0xD1317C0A5AF14BE8BD729D21956EDB30, 3);
INSERT INTO nataly_schema.Message_templates (profile_id, text_id, text_number) VALUES ('1001636771', 0xDB6F2B91AD684E78A98DE87D27471304, 4);
INSERT INTO nataly_schema.Message_templates (profile_id, text_id, text_number) VALUES ('1001650728', 0x0548D75B879648339B5FF85848350B6A, 2);
INSERT INTO nataly_schema.Message_templates (profile_id, text_id, text_number) VALUES ('1001663985', 0x7BA508701A4E426B86A3844DEF9F1603, 1);