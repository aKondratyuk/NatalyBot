create table Privileges
(
    privilege_name varchar(190) not null
        primary key
)
    charset = utf8;

INSERT INTO nataly_schema.Privileges (privilege_name) VALUES ('PROFILES_VISIBILITY');
INSERT INTO nataly_schema.Privileges (privilege_name) VALUES ('USER_EDIT');