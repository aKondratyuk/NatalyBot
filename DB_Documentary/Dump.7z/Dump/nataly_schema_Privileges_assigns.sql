create table Privileges_assigns
(
    user_role        varchar(190)         not null,
    privilege_name   varchar(190)         not null,
    privilege_status tinyint(1) default 0 null,
    primary key (user_role, privilege_name),
    constraint FK_PREVILEG_PREVILEGE_PRIVILEG
        foreign key (privilege_name) references Privileges (privilege_name),
    constraint FK_PREVILEG_ROLE_HAS__USER_ROL
        foreign key (user_role) references User_roles (user_role)
);

INSERT INTO nataly_schema.Privileges_assigns (user_role, privilege_name, privilege_status) VALUES ('admin', 'PROFILES_VISIBILITY', 1);
INSERT INTO nataly_schema.Privileges_assigns (user_role, privilege_name, privilege_status) VALUES ('admin', 'USER_EDIT', 1);