create table Profile_languages
(
    language   varchar(190) not null,
    level_name varchar(190) not null,
    profile_id varchar(20)  not null,
    primary key (language, level_name, profile_id),
    constraint FK_PROFILE__PROFILE_K_LANGUAGE
        foreign key (level_name) references Levels (level_name),
    constraint FK_PROFILE__PROFILE_K_PROFILE_
        foreign key (profile_id) references Profiles (profile_id),
    constraint Profile_languages_Languages_language_fk
        foreign key (language) references Languages (language)
);

INSERT INTO nataly_schema.Profile_languages (language, level_name, profile_id) VALUES ('English', 'Intermediate', '1000868043');
INSERT INTO nataly_schema.Profile_languages (language, level_name, profile_id) VALUES ('Russian', 'Good', '1000868043');
INSERT INTO nataly_schema.Profile_languages (language, level_name, profile_id) VALUES ('Ukrainian', 'Fluent', '1000868043');
INSERT INTO nataly_schema.Profile_languages (language, level_name, profile_id) VALUES ('English', 'Basic', '1001485714');
INSERT INTO nataly_schema.Profile_languages (language, level_name, profile_id) VALUES ('Mandarin', 'Fluent', '1001485714');
INSERT INTO nataly_schema.Profile_languages (language, level_name, profile_id) VALUES ('English', 'Intermediate', '1001573218');
INSERT INTO nataly_schema.Profile_languages (language, level_name, profile_id) VALUES ('Spanish', 'Fluent', '1001573218');
INSERT INTO nataly_schema.Profile_languages (language, level_name, profile_id) VALUES ('English', 'Intermediate', '1001650728');
INSERT INTO nataly_schema.Profile_languages (language, level_name, profile_id) VALUES ('Russian', 'Fluent', '1001650728');
INSERT INTO nataly_schema.Profile_languages (language, level_name, profile_id) VALUES ('Ukrainian', 'Fluent', '1001650728');
INSERT INTO nataly_schema.Profile_languages (language, level_name, profile_id) VALUES ('English', 'Basic', '1001651264');
INSERT INTO nataly_schema.Profile_languages (language, level_name, profile_id) VALUES ('Russian', 'Fluent', '1001651264');
INSERT INTO nataly_schema.Profile_languages (language, level_name, profile_id) VALUES ('Ukrainian', 'Fluent', '1001651264');
INSERT INTO nataly_schema.Profile_languages (language, level_name, profile_id) VALUES ('English', 'Good', '1001663985');
INSERT INTO nataly_schema.Profile_languages (language, level_name, profile_id) VALUES ('Russian', 'Fluent', '1001663985');
INSERT INTO nataly_schema.Profile_languages (language, level_name, profile_id) VALUES ('Ukrainian', 'Fluent', '1001663985');
INSERT INTO nataly_schema.Profile_languages (language, level_name, profile_id) VALUES ('English', 'Intermediate', '1001668497');
INSERT INTO nataly_schema.Profile_languages (language, level_name, profile_id) VALUES ('Russian', 'Fluent', '1001668497');
INSERT INTO nataly_schema.Profile_languages (language, level_name, profile_id) VALUES ('Ukrainian', 'Fluent', '1001668497');