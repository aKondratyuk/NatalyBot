create table Tags
(
    tag varchar(190) not null
        primary key
);

