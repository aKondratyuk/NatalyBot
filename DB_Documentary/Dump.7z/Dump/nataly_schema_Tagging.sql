create table Tagging
(
    text_id binary(16)   not null,
    tag     varchar(190) not null,
    primary key (text_id, tag),
    constraint FK_TAGGING_TAGGING2_TAGS
        foreign key (tag) references Tags (tag),
    constraint FK_TAGGING_TAGGING_Texts
        foreign key (text_id) references Texts (text_id)
);

