create table Tags
(
    tag       varchar(190)         not null
        primary key,
    forbidden tinyint(1) default 0 null
)
    charset = utf8;

INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('11', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('123123123', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('132312', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('213', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('324', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('324sad', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('asdas', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('bot profile', 1);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('Can I buy your contact request at the agency?', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('Can I buy your contact request at the agency? Can I get your private information, your email at the agency?', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('Can I buy your contact request at the agency? Can I get your private information, your email at the agency?:)', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('Can I get your private information, your email at the agency?', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('check system', 1);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('Do you like cars?', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('Do you want to have children how many children?', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('Have You ever been abroad?', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('hello', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('I am very sorry I have already found some one here, another lady.', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('I engoy reading books', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('I had some bad experience of this site. I don/''t trust the ladies here. They are scammers.', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('I like swiming', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('I tired of this life', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('Is it possible for you to come in my country?', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('Is it possible for you to organize our meeting?', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('norm', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('ogo', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('okey10okey10okey10okey10okey10', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('okey1okey1okey1okey1okey1okey1', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('okey2okey2okey2okey2okey2okey2', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('okey3okey3okey3okey3okey3okey3', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('okey4okey4okey4okey4okey4okey4', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('okey5okey5okey5okey5okey5okey5', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('okey6okey6okey6okey6okey6okey6', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('okey7okey7okey7okey7okey7okey7', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('okey8okey8okey8okey8okey8okey8', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('okey9okey9okey9okey9okey9okey9', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('Please describe what happen in future when we are together?', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('privet', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('sdf', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('sdfghj', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('template', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('Test profile', 1);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('test1', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('test12', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('test122', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('test1222', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('test2', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('test_delete', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('Thanks for your message but I/''m interested with other woman and im sure you will find a nice man very soon.', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('What are you favorite types of music?', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('What are you waiting from our correspondence? ', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('What are you wishing for in a relationship what do you expect from me', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('What are you wishing for in a relationship what do you expect from me.', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('What do you like to read?', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('What do you think about our future family?', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('What types of food do you enjoy?', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('What would be an ideal house for you?', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('What you think about age difference? you are pretty very beautiful but too young. Our age difference is very big. I am way to old for you?', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('Администрация', 1);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('кеукеу', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('повлечет проблемы', 1);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('проблемы', 1);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('проверка', 1);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('рассылка программой', 1);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('сайт', 1);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('укеукеукеук', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('укеукеукеуке', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('уяввы', 0);
INSERT INTO nataly_schema.Tags (tag, forbidden) VALUES ('фыфы', 0);